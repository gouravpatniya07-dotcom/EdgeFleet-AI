<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>EdgeFleet AI</title>
    <meta name="description" content="EdgeFleet AI - Distributed peer-to-peer fleet coordination simulation for autonomous mobile robots in smart warehouses with real-time trajectory deconfliction." />
    <meta property="og:title" content="EdgeFleet AI" />
    <meta property="og:description" content="EdgeFleet AI - Distributed peer-to-peer fleet coordination simulation for autonomous mobile robots in smart warehouses with real-time trajectory deconfliction." />
    <meta property="og:type" content="website" />
    <meta name="twitter:card" content="summary_large_image" />
    <script src="https://cdn.jsdelivr.net/npm/d3@7"></script>
    <style>
      :root {
        --bg-main: #090d16;
        --bg-panel: #0f172a;
        --bg-card: #141e33;
        --bg-card-hover: #1b2844;
        --border-subtle: #1e293b;
        --border-bright: #334155;
        --text-primary: #f8fafc;
        --text-secondary: #94a3b8;
        --text-muted: #64748b;
        --accent-cyan: #06b6d4;
        --accent-amber: #f59e0b;
        --accent-emerald: #10b981;
        --accent-purple: #a855f7;
        --accent-red: #ef4444;
        --accent-blue: #3b82f6;
        --font-sans: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", sans-serif;
        --font-mono: ui-monospace, "SF Mono", Menlo, Consolas, monospace;
      }

      * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
      }

      html, body {
        width: 100%;
        height: 100%;
        background-color: var(--bg-main);
        color: var(--text-primary);
        font-family: var(--font-sans);
        overflow: hidden;
        user-select: none;
      }

      #app-layout {
        display: flex;
        flex-direction: column;
        width: 100vw;
        height: 100vh;
      }

      /* Header */
      header {
        height: 54px;
        background: var(--bg-panel);
        border-bottom: 1px solid var(--border-subtle);
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 16px;
        flex-shrink: 0;
        z-index: 20;
      }

      .logo-group {
        display: flex;
        align-items: center;
        gap: 12px;
      }

      .logo-icon {
        width: 32px;
        height: 32px;
        border-radius: 8px;
        background: linear-gradient(135deg, #0ea5e9, #0284c7);
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 0 12px rgba(14, 165, 233, 0.4);
      }

      .logo-icon svg {
        width: 18px;
        height: 18px;
        fill: none;
        stroke: #fff;
        stroke-width: 2;
      }

      .logo-text h1 {
        font-size: 14px;
        font-weight: 700;
        letter-spacing: 0.5px;
        color: var(--text-primary);
        text-transform: uppercase;
        display: flex;
        align-items: center;
        gap: 8px;
      }

      .logo-text p {
        font-size: 11px;
        color: var(--text-secondary);
        font-family: var(--font-mono);
      }

      .badge-live {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        font-size: 10px;
        font-weight: 600;
        padding: 2px 7px;
        border-radius: 9999px;
        background: rgba(16, 185, 129, 0.15);
        color: var(--accent-emerald);
        border: 1px solid rgba(16, 185, 129, 0.3);
      }

      .pulse-dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: var(--accent-emerald);
        box-shadow: 0 0 8px var(--accent-emerald);
        animation: pulse 1.6s infinite;
      }

      @keyframes pulse {
        0%, 100% { opacity: 1; transform: scale(1); }
        50% { opacity: 0.4; transform: scale(0.8); }
      }

      .header-stats {
        display: flex;
        align-items: center;
        gap: 16px;
      }

      .stat-pill {
        display: flex;
        flex-direction: column;
        align-items: flex-end;
      }

      .stat-pill .label {
        font-size: 9px;
        text-transform: uppercase;
        color: var(--text-muted);
        letter-spacing: 0.5px;
        font-family: var(--font-mono);
      }

      .stat-pill .value {
        font-size: 13px;
        font-weight: 700;
        font-family: var(--font-mono);
        color: var(--accent-cyan);
      }

      .header-actions {
        display: flex;
        align-items: center;
        gap: 8px;
      }

      /* Main Layout: Canvas Area + Sidebar */
      #main-content {
        flex: 1;
        display: flex;
        position: relative;
        overflow: hidden;
      }

      /* Canvas Stage */
      #viewport-container {
        flex: 1;
        position: relative;
        overflow: hidden;
        background-color: #060911;
      }

      #sim-canvas {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        display: block;
        cursor: crosshair;
      }

      /* Dedicated Sub-Navigation Toolbar */
      #sim-nav-bar {
        background: #090e1a;
        border-bottom: 1px solid var(--border-subtle);
        padding: 6px 14px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        flex-wrap: wrap;
        flex-shrink: 0;
        z-index: 15;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.45);
      }

      .nav-group-cluster {
        display: flex;
        align-items: center;
        gap: 8px;
        flex-wrap: wrap;
      }

      .nav-divider {
        width: 1px;
        height: 22px;
        background: var(--border-subtle);
        margin: 0 4px;
      }

      .nav-group-label {
        font-size: 10px;
        font-family: var(--font-mono);
        color: var(--accent-cyan);
        font-weight: 700;
        letter-spacing: 0.5px;
        text-transform: uppercase;
        margin-right: 2px;
      }

      /* Compact Nav Dropdown Containers */
      .nav-dropdown-wrapper {
        position: relative;
        display: inline-block;
      }

      .nav-btn {
        background: rgba(15, 23, 42, 0.95);
        border: 1px solid var(--border-subtle);
        color: var(--text-primary);
        padding: 5px 11px;
        border-radius: 6px;
        font-size: 11.5px;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        cursor: pointer;
        transition: all 0.15s ease;
      }

      .nav-btn:hover {
        background: var(--bg-card-hover);
        border-color: var(--accent-cyan);
        color: #fff;
      }

      .nav-btn.open, .nav-btn.active {
        border-color: var(--accent-cyan);
        background: rgba(6, 182, 212, 0.18);
        color: var(--accent-cyan);
      }

      .nav-btn .chevron-icon {
        width: 10px;
        height: 10px;
        fill: currentColor;
        transition: transform 0.18s ease;
      }

      .nav-btn.open .chevron-icon {
        transform: rotate(180deg);
      }

      .nav-dropdown-menu {
        position: absolute;
        top: calc(100% + 6px);
        left: 0;
        background: #0b1120;
        border: 1px solid var(--border-bright);
        border-radius: 8px;
        padding: 6px;
        min-width: 190px;
        display: none;
        flex-direction: column;
        gap: 4px;
        box-shadow: 0 12px 28px rgba(0, 0, 0, 0.65), 0 0 0 1px rgba(6, 182, 212, 0.15);
        z-index: 100;
      }

      .nav-dropdown-menu.show {
        display: flex;
        animation: fadeInMenu 0.15s ease-out;
      }

      @keyframes fadeInMenu {
        from { opacity: 0; transform: translateY(-4px); }
        to { opacity: 1; transform: translateY(0); }
      }

      .nav-dropdown-menu .dropdown-header {
        font-size: 9.5px;
        font-family: var(--font-mono);
        color: var(--accent-cyan);
        text-transform: uppercase;
        letter-spacing: 0.5px;
        padding: 4px 8px 2px 8px;
        font-weight: 700;
      }

      .nav-dropdown-menu .dropdown-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        padding: 6px 10px;
        border-radius: 5px;
        background: transparent;
        border: none;
        color: var(--text-primary);
        font-size: 11.5px;
        font-weight: 500;
        cursor: pointer;
        text-align: left;
        width: 100%;
        transition: background 0.12s ease;
      }

      .nav-dropdown-menu .dropdown-item:hover {
        background: rgba(255, 255, 255, 0.08);
        color: #fff;
      }

      .nav-dropdown-menu .dropdown-item.active {
        background: rgba(6, 182, 212, 0.18);
        color: var(--accent-cyan);
        font-weight: 600;
      }

      .nav-dropdown-menu .dropdown-item .item-check {
        font-size: 10px;
        color: var(--accent-cyan);
      }

      .nav-dropdown-menu .dropdown-divider {
        height: 1px;
        background: var(--border-subtle);
        margin: 4px 0;
      }

      .ctrl-card {
        background: rgba(15, 23, 42, 0.9);
        border: 1px solid var(--border-subtle);
        border-radius: 6px;
        padding: 3px 8px;
        display: inline-flex;
        align-items: center;
        gap: 6px;
      }

      button {
        font-family: var(--font-sans);
        font-size: 12px;
        font-weight: 600;
        border: 1px solid var(--border-subtle);
        background: var(--bg-card);
        color: var(--text-primary);
        padding: 5px 10px;
        border-radius: 5px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 5px;
        white-space: nowrap;
        transition: all 0.15s ease;
      }

      button:hover {
        background: var(--bg-card-hover);
        border-color: var(--border-bright);
      }

      button.active {
        background: rgba(6, 182, 212, 0.2);
        color: var(--accent-cyan);
        border-color: var(--accent-cyan);
      }

      button.btn-primary {
        background: #0284c7;
        border-color: #38bdf8;
        color: #fff;
      }

      button.btn-primary:hover {
        background: #0369a1;
      }

      button.btn-danger {
        background: rgba(239, 68, 68, 0.15);
        border-color: rgba(239, 68, 68, 0.3);
        color: #f87171;
      }

      button.btn-danger:hover {
        background: rgba(239, 68, 68, 0.3);
      }

      .toggle-btn {
        padding: 3px 8px;
        font-size: 11px;
      }

      /* Floating Zoom & Pan Controls on Canvas Viewport */
      .canvas-zoom-controls {
        position: absolute;
        top: 14px;
        right: 14px;
        display: flex;
        flex-direction: column;
        gap: 4px;
        background: rgba(11, 17, 32, 0.92);
        border: 1px solid var(--border-bright);
        border-radius: 8px;
        padding: 4px;
        z-index: 20;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.6), 0 0 0 1px rgba(6, 182, 212, 0.2);
        backdrop-filter: blur(10px);
      }

      .canvas-zoom-btn {
        width: 32px;
        height: 32px;
        background: rgba(15, 23, 42, 0.85);
        border: 1px solid var(--border-subtle);
        border-radius: 6px;
        color: var(--text-primary);
        font-size: 14px;
        font-weight: 700;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0;
        cursor: pointer;
        transition: all 0.15s ease;
      }

      .canvas-zoom-btn:hover {
        background: rgba(6, 182, 212, 0.2);
        border-color: var(--accent-cyan);
        color: #fff;
      }

      .canvas-zoom-indicator {
        font-family: var(--font-mono);
        font-size: 9.5px;
        color: var(--accent-cyan);
        text-align: center;
        padding: 2px 0;
        font-weight: 700;
        letter-spacing: 0.3px;
        user-select: none;
      }

      /* Scenario Preset Bar Bottom of Canvas */
      .canvas-bottom-bar {
        position: absolute;
        bottom: 14px;
        left: 14px;
        right: 14px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        pointer-events: none;
        z-index: 10;
      }

      .scenario-pills {
        display: flex;
        gap: 6px;
        pointer-events: auto;
        background: rgba(15, 23, 42, 0.9);
        backdrop-filter: blur(8px);
        padding: 6px;
        border-radius: 8px;
        border: 1px solid var(--border-subtle);
      }

      .scenario-pills .title-tag {
        font-size: 10px;
        font-family: var(--font-mono);
        color: var(--text-muted);
        text-transform: uppercase;
        display: flex;
        align-items: center;
        padding: 0 6px;
      }

      .canvas-legend {
        pointer-events: auto;
        display: flex;
        align-items: center;
        gap: 12px;
        background: rgba(15, 23, 42, 0.85);
        backdrop-filter: blur(8px);
        border: 1px solid var(--border-subtle);
        padding: 6px 12px;
        border-radius: 8px;
        font-size: 11px;
        color: var(--text-secondary);
      }

      .legend-item {
        display: flex;
        align-items: center;
        gap: 6px;
      }

      .legend-circle {
        width: 10px;
        height: 10px;
        border-radius: 50%;
      }

      /* Right Sidebar HUD */
      #hud-sidebar {
        width: 420px;
        background: var(--bg-panel);
        border-left: 1px solid var(--border-subtle);
        display: flex;
        flex-direction: column;
        flex-shrink: 0;
        overflow: hidden;
      }

      .tab-header {
        display: flex;
        border-bottom: 1px solid var(--border-subtle);
        background: rgba(10, 15, 29, 0.6);
      }

      .tab-btn {
        flex: 1;
        background: transparent;
        border: none;
        border-bottom: 2px solid transparent;
        border-radius: 0;
        padding: 10px 8px;
        font-size: 11px;
        color: var(--text-secondary);
        text-transform: uppercase;
        letter-spacing: 0.5px;
        justify-content: center;
        font-weight: 600;
      }

      .tab-btn.active {
        color: var(--accent-cyan);
        border-bottom-color: var(--accent-cyan);
        background: rgba(6, 182, 212, 0.05);
      }

      .tab-pane {
        flex: 1;
        overflow-y: auto;
        padding: 14px;
        display: flex;
        flex-direction: column;
        gap: 12px;
      }

      .tab-pane::-webkit-scrollbar {
        width: 5px;
      }

      .tab-pane::-webkit-scrollbar-thumb {
        background: var(--border-bright);
        border-radius: 4px;
      }

      /* Robot Fleet Cards */
      .robot-card {
        background: var(--bg-card);
        border: 1px solid var(--border-subtle);
        border-radius: 8px;
        padding: 12px;
        display: flex;
        flex-direction: column;
        gap: 10px;
        transition: border-color 0.2s ease, transform 0.15s ease;
        position: relative;
      }

      .robot-card:hover {
        border-color: var(--border-bright);
      }

      .robot-card.selected {
        border-color: var(--accent-cyan);
        box-shadow: 0 0 12px rgba(6, 182, 212, 0.2);
      }

      .robot-card-top {
        display: flex;
        align-items: center;
        justify-content: space-between;
      }

      .robot-identity {
        display: flex;
        align-items: center;
        gap: 8px;
      }

      .robot-id-tag {
        font-size: 11px;
        font-weight: 700;
        padding: 2px 6px;
        border-radius: 4px;
        font-family: var(--font-mono);
      }

      .robot-name {
        font-size: 13px;
        font-weight: 700;
      }

      .status-pill {
        font-size: 10px;
        font-weight: 700;
        padding: 2px 8px;
        border-radius: 9999px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        display: inline-flex;
        align-items: center;
        gap: 4px;
      }

      .status-navigating {
        background: rgba(16, 185, 129, 0.15);
        color: var(--accent-emerald);
        border: 1px solid rgba(16, 185, 129, 0.3);
      }

      .status-yielding {
        background: rgba(245, 158, 11, 0.15);
        color: var(--accent-amber);
        border: 1px solid rgba(245, 158, 11, 0.3);
      }

      .status-detouring {
        background: rgba(168, 85, 247, 0.15);
        color: var(--accent-purple);
        border: 1px solid rgba(168, 85, 247, 0.3);
      }

      .status-blocked {
        background: rgba(239, 68, 68, 0.15);
        color: var(--accent-red);
        border: 1px solid rgba(239, 68, 68, 0.3);
      }

      .status-charging {
        background: rgba(6, 182, 212, 0.15);
        color: var(--accent-cyan);
        border: 1px solid rgba(6, 182, 212, 0.3);
      }

      .robot-meta-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 8px;
        background: rgba(10, 15, 29, 0.5);
        padding: 8px;
        border-radius: 6px;
        border: 1px solid rgba(255, 255, 255, 0.04);
      }

      .meta-item {
        display: flex;
        flex-direction: column;
      }

      .meta-label {
        font-size: 9px;
        color: var(--text-muted);
        text-transform: uppercase;
        font-family: var(--font-mono);
      }

      .meta-value {
        font-size: 11px;
        font-weight: 600;
        color: var(--text-primary);
        font-family: var(--font-mono);
      }

      .battery-track {
        height: 6px;
        width: 100%;
        background: rgba(255, 255, 255, 0.08);
        border-radius: 999px;
        overflow: hidden;
        position: relative;
      }

      .battery-fill {
        height: 100%;
        border-radius: 999px;
        transition: width 0.3s ease, background 0.3s ease;
      }

      .robot-footer {
        display: flex;
        align-items: center;
        justify-content: space-between;
        font-size: 11px;
        color: var(--text-secondary);
      }

      .priority-badge {
        font-size: 10px;
        font-family: var(--font-mono);
        font-weight: 700;
        padding: 1px 6px;
        border-radius: 4px;
        background: rgba(255, 255, 255, 0.07);
      }

      .card-actions {
        display: flex;
        gap: 4px;
      }

      .mini-btn {
        padding: 2px 6px;
        font-size: 10px;
      }

      /* Live P2P Telemetry Log */
      .telemetry-container {
        display: flex;
        flex-direction: column;
        height: 100%;
        gap: 8px;
      }

      .log-toolbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
      }

      .log-filter-select {
        background: var(--bg-card);
        color: var(--text-primary);
        border: 1px solid var(--border-subtle);
        border-radius: 4px;
        font-size: 11px;
        padding: 3px 8px;
        font-family: var(--font-mono);
      }

      #telemetry-log {
        flex: 1;
        background: #060911;
        border: 1px solid var(--border-subtle);
        border-radius: 6px;
        padding: 10px;
        font-family: var(--font-mono);
        font-size: 10.5px;
        line-height: 1.45;
        overflow-y: auto;
        display: flex;
        flex-direction: column;
        gap: 5px;
      }

      #telemetry-log::-webkit-scrollbar {
        width: 4px;
      }

      #telemetry-log::-webkit-scrollbar-thumb {
        background: var(--border-bright);
        border-radius: 4px;
      }

      .log-row {
        display: flex;
        gap: 6px;
        word-break: break-all;
      }

      .log-time {
        color: var(--text-muted);
        flex-shrink: 0;
      }

      .log-tag {
        font-weight: 700;
        flex-shrink: 0;
      }

      .log-tag-p2p { color: var(--accent-cyan); }
      .log-tag-deconflict { color: var(--accent-amber); }
      .log-tag-detour { color: var(--accent-purple); }
      .log-tag-obstacle { color: var(--accent-red); }
      .log-tag-mission { color: var(--accent-emerald); }
      .log-tag-battery { color: #38bdf8; }

      .log-msg {
        color: var(--text-secondary);
      }

      /* Technical Architecture Guide Modal/Drawer */
      .info-box {
        background: rgba(6, 182, 212, 0.05);
        border: 1px solid rgba(6, 182, 212, 0.2);
        border-radius: 8px;
        padding: 12px;
        font-size: 11.5px;
        line-height: 1.5;
        color: var(--text-secondary);
      }

      .info-box h4 {
        color: var(--accent-cyan);
        font-size: 12px;
        font-weight: 700;
        margin-bottom: 6px;
      }

      .flow-step {
        margin-bottom: 8px;
        padding-left: 12px;
        border-left: 2px solid var(--border-bright);
      }

      .flow-step strong {
        color: var(--text-primary);
      }

      /* D3 Chart in Architecture Tab */
      .d3-axis text {
        fill: #64748b;
        font-family: var(--font-mono);
        font-size: 9px;
      }
      .d3-axis line, .d3-axis path {
        stroke: #1e293b;
      }
      .d3-grid line {
        stroke: rgba(255, 255, 255, 0.05);
      }
      .d3-area {
        fill: url(#d3-throughput-gradient);
      }
      .d3-line {
        fill: none;
        stroke: #06b6d4;
        stroke-width: 2.2;
        filter: drop-shadow(0 0 6px rgba(6, 182, 212, 0.45));
      }
      .d3-point {
        fill: #06b6d4;
        stroke: #fff;
        stroke-width: 1.5;
      }

      /* Responsive styling */
      @media (max-width: 900px) {
        #main-content {
          flex-direction: column;
        }
        #hud-sidebar {
          width: 100%;
          height: 320px;
          border-left: none;
          border-top: 1px solid var(--border-subtle);
        }
      }

      /* AI Copilot & Media Studio Styles */
      .chat-content {
        font-size: 11px;
        line-height: 1.55;
        color: var(--text-primary);
      }
      .chat-content p {
        margin-bottom: 6px;
      }
      .chat-content p:last-child {
        margin-bottom: 0;
      }
      .chat-content ul, .chat-content ol {
        margin-left: 16px;
        margin-bottom: 6px;
      }
      .chat-content li {
        margin-bottom: 3px;
      }
      .chat-content code {
        background: rgba(0, 0, 0, 0.4);
        border: 1px solid rgba(255, 255, 255, 0.1);
        padding: 1px 4px;
        border-radius: 3px;
        font-family: var(--font-mono);
        color: var(--accent-cyan);
      }
      .chat-content pre {
        background: #000;
        border: 1px solid var(--border-subtle);
        padding: 8px;
        border-radius: 4px;
        overflow-x: auto;
        margin: 6px 0;
      }
      .chat-content pre code {
        border: none;
        padding: 0;
        background: transparent;
      }
      .chat-content strong {
        color: #fff;
      }
      .toggle-btn {
        font-size: 10px;
        font-family: var(--font-mono);
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid var(--border-subtle);
        color: var(--text-secondary);
        padding: 2px 7px;
        border-radius: 4px;
        cursor: pointer;
        transition: all 0.2s ease;
      }
      .toggle-btn:hover {
        background: rgba(255, 255, 255, 0.1);
        color: #fff;
      }
      .toggle-btn.active {
        background: rgba(6, 182, 212, 0.2);
        border-color: var(--accent-cyan);
        color: var(--accent-cyan);
      }
      .btn-danger {
        background: rgba(239, 68, 68, 0.2) !important;
        border-color: rgba(239, 68, 68, 0.5) !important;
        color: #f87171 !important;
      }
      .btn-danger:hover {
        background: rgba(239, 68, 68, 0.35) !important;
      }
      .quick-prompt {
        white-space: nowrap;
        font-size: 9.5px;
        padding: 3px 7px;
        border-radius: 999px;
        background: rgba(255, 255, 255, 0.04);
        border: 1px solid var(--border-subtle);
        color: var(--text-secondary);
        cursor: pointer;
        flex-shrink: 0;
      }
      .quick-prompt:hover {
        background: rgba(6, 182, 212, 0.15);
        border-color: var(--accent-cyan);
        color: #fff;
      }
      .studio-subtab {
        flex: 1;
        text-align: center;
        padding: 5px 0;
        border-radius: 4px 4px 0 0;
        border-bottom: 2px solid transparent;
        background: transparent;
        color: var(--text-secondary);
      }
      .studio-subtab.active {
        color: var(--accent-cyan);
        border-bottom: 2px solid var(--accent-cyan);
        background: rgba(6, 182, 212, 0.08);
      }

      /* Manual Inspector & Editor Modals */
      .modal-backdrop {
        position: fixed;
        inset: 0;
        background: rgba(4, 7, 14, 0.82);
        backdrop-filter: blur(5px);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1000;
        padding: 16px;
      }
      .modal-backdrop.hidden {
        display: none !important;
      }
      .modal-box {
        background: #090e1a;
        border: 1px solid var(--border-bright);
        box-shadow: 0 20px 50px rgba(0, 0, 0, 0.85), 0 0 20px rgba(6, 182, 212, 0.12);
        border-radius: 10px;
        width: 100%;
        max-width: 680px;
        max-height: 90vh;
        overflow-y: auto;
        display: flex;
        flex-direction: column;
        gap: 14px;
        padding: 18px;
        color: var(--text-primary);
      }
      .modal-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        border-bottom: 1px solid var(--border-subtle);
        padding-bottom: 10px;
      }
      .modal-header h3 {
        font-size: 13px;
        font-weight: 700;
        letter-spacing: 0.04em;
        color: var(--accent-cyan);
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .modal-close-btn {
        background: transparent;
        border: none;
        color: var(--text-muted);
        cursor: pointer;
        font-size: 18px;
        line-height: 1;
        padding: 2px 6px;
        border-radius: 4px;
      }
      .modal-close-btn:hover {
        color: #fff;
        background: rgba(255, 255, 255, 0.1);
      }
      .modal-grid-2col {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 14px;
      }
      @media (max-width: 640px) {
        .modal-grid-2col {
          grid-template-columns: 1fr;
        }
      }
      .form-group {
        display: flex;
        flex-direction: column;
        gap: 4px;
      }
      .form-label {
        font-size: 10px;
        font-family: var(--font-mono);
        color: var(--text-muted);
        text-transform: uppercase;
        display: flex;
        justify-content: space-between;
      }
      .form-input, .form-select {
        background: #04070e;
        border: 1px solid var(--border-subtle);
        border-radius: 5px;
        color: var(--text-primary);
        font-size: 11.5px;
        padding: 6px 8px;
        font-family: var(--font-mono);
      }
      .form-input:focus, .form-select:focus {
        outline: none;
        border-color: var(--accent-cyan);
        box-shadow: 0 0 8px rgba(6, 182, 212, 0.25);
      }
      .form-range {
        accent-color: var(--accent-cyan);
        cursor: pointer;
      }
      .dpad-grid {
        display: grid;
        grid-template-columns: repeat(3, 44px);
        grid-template-rows: repeat(3, 38px);
        gap: 6px;
        justify-content: center;
        align-items: center;
        background: #04070e;
        padding: 10px;
        border-radius: 8px;
        border: 1px solid var(--border-subtle);
      }
      .dpad-btn {
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid var(--border-subtle);
        color: var(--text-primary);
        border-radius: 6px;
        font-size: 12px;
        font-weight: 700;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        user-select: none;
        transition: all 0.15s ease;
      }
      .dpad-btn:hover {
        background: rgba(6, 182, 212, 0.2);
        border-color: var(--accent-cyan);
        color: #fff;
      }
      .dpad-btn:active {
        background: var(--accent-cyan);
        color: #000;
      }
      .badge-btn-group {
        display: flex;
        gap: 4px;
        flex-wrap: wrap;
      }
      .amr-selector-tab {
        flex: 1;
        padding: 5px 8px;
        font-size: 10.5px;
        font-family: var(--font-mono);
        border: 1px solid var(--border-subtle);
        background: rgba(255, 255, 255, 0.03);
        color: var(--text-secondary);
        border-radius: 5px;
        cursor: pointer;
        text-align: center;
        transition: all 0.15s ease;
      }
      .amr-selector-tab.active {
        border-color: var(--accent-cyan);
        background: rgba(6, 182, 212, 0.15);
        color: #fff;
        font-weight: 700;
      }
    </style>
  </head>
  <body>
    <div id="app-layout">
      <!-- Header -->
      <header id="app-header">
        <div class="logo-group">
          <div class="logo-icon">
            <svg viewBox="0 0 24 24">
              <circle cx="12" cy="12" r="3" />
              <path d="M12 2v3m0 14v3M2 12h3m14 0h3m-3.5-6.5l-2.1 2.1m-8.8 8.8l-2.1 2.1m0-13l2.1 2.1m8.8 8.8l2.1 2.1" />
            </svg>
          </div>
          <div class="logo-text">
            <h1>EdgeFleet AI <span class="badge-live"><span class="pulse-dot"></span> P2P MESH ACTIVE</span></h1>
            <p>Space-Time Horizon Trajectory Deconfliction & Decentralized Negotiation</p>
          </div>
        </div>

        <div class="header-stats">
          <div class="stat-pill">
            <span class="label">Sim Clock</span>
            <span class="value" id="hdr-sim-time">00:00.0</span>
          </div>
          <div class="stat-pill">
            <span class="label">P2P Packets/s</span>
            <span class="value" id="hdr-packets">0</span>
          </div>
          <div class="stat-pill">
            <span class="label">Deconflictions</span>
            <span class="value" id="hdr-deconflictions" style="color: var(--accent-amber);">0</span>
          </div>
          <div class="stat-pill">
            <span class="label">Deliveries</span>
            <span class="value" id="hdr-deliveries" style="color: var(--accent-emerald);">0</span>
          </div>
          <div class="stat-pill">
            <span class="label">Collisions</span>
            <span class="value" id="hdr-collisions" style="color: var(--accent-emerald);">0</span>
          </div>
        </div>

        <div class="header-actions"></div>
      </header>

      <!-- Main Stage -->
      <!-- Clean Dedicated Navigation & Control Bar -->
      <nav id="sim-nav-bar">
        <!-- Cluster 1: Playback & Clock Speed -->
        <div class="nav-group-cluster">
          <div class="ctrl-card">
            <button id="btn-play-pause" class="btn-primary" title="Play or Pause Simulation (Spacebar)">
              <svg style="width:13px; height:13px; fill:currentColor;" viewBox="0 0 24 24" id="icon-play-pause">
                <path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/>
              </svg>
              <span id="txt-play-pause">Pause</span>
            </button>

            <button id="btn-step" class="mini-btn" title="Step one frame forward">
              <svg style="width:13px; height:13px; fill:currentColor;" viewBox="0 0 24 24">
                <path d="M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z"/>
              </svg>
              Step
            </button>

            <button id="btn-reset" class="mini-btn" title="Reset AMR Fleet and Tasks">
              <svg style="width:13px; height:13px; fill:currentColor;" viewBox="0 0 24 24">
                <path d="M17.65 6.35A7.958 7.958 0 0012 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08A5.99 5.99 0 0112 18c-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/>
              </svg>
              Reset
            </button>
          </div>

          <div class="ctrl-card">
            <span style="font-size:10px; font-family:var(--font-mono); color:var(--text-secondary);">SPEED:</span>
            <button class="toggle-btn" data-speed="1.0" id="speed-1x">1x</button>
            <button class="toggle-btn active" data-speed="2.0" id="speed-2x">2x</button>
            <button class="toggle-btn" data-speed="4.0" id="speed-4x">4x</button>
          </div>
        </div>

        <div class="nav-divider"></div>

        <!-- Cluster 2: Tool & View Nav Dropdown Menus -->
        <div class="nav-group-cluster">
          <!-- Tools Nav Button & Dropdown -->
          <div class="nav-dropdown-wrapper" id="tool-dropdown-wrapper">
            <button class="nav-btn" id="btn-nav-tool" title="Interactive Warehouse Floor Tools">
              <span id="current-tool-icon">🖱️</span>
              <span id="current-tool-name">Tool: Select</span>
              <svg class="chevron-icon" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>
            </button>
            <div class="nav-dropdown-menu" id="menu-nav-tool">
              <div class="dropdown-header">Floor Tools</div>
              <button class="dropdown-item active" data-tool="select">
                <span>🖱️ Select AMR</span>
                <span class="item-check">✓</span>
              </button>
              <button class="dropdown-item" data-tool="pan">
                <span>✋ Pan / Move Canvas</span>
                <span class="item-check" style="display:none;">✓</span>
              </button>
              <button class="dropdown-item" data-tool="target">
                <span>🎯 Destination Waypoint</span>
                <span class="item-check" style="display:none;">✓</span>
              </button>
              <button class="dropdown-item" data-tool="draw">
                <span>🧱 Draw Spill Obstacle</span>
                <span class="item-check" style="display:none;">✓</span>
              </button>
              <button class="dropdown-item" data-tool="erase">
                <span>🧽 Erase Spill</span>
                <span class="item-check" style="display:none;">✓</span>
              </button>
              <button class="dropdown-item" data-tool="station">
                <span>📌 Add Station Dock</span>
                <span class="item-check" style="display:none;">✓</span>
              </button>
              <button class="dropdown-item" data-tool="teleport">
                <span>⚡ Instant Teleport</span>
                <span class="item-check" style="display:none;">✓</span>
              </button>
              <div class="dropdown-divider"></div>
              <button class="dropdown-item" id="btn-clear-obstacles" style="color: #f87171;">
                <span>🗑️ Clear Floor Obstacles</span>
              </button>
            </div>
          </div>

          <!-- View Layers Nav Button & Dropdown -->
          <div class="nav-dropdown-wrapper" id="view-dropdown-wrapper">
            <button class="nav-btn" id="btn-nav-view" title="Toggle Fleet Overlay Visualization Layers">
              <span>👁️</span>
              <span>View Layers</span>
              <svg class="chevron-icon" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>
            </button>
            <div class="nav-dropdown-menu" id="menu-nav-view">
              <div class="dropdown-header">Simulation Overlays</div>
              <button class="dropdown-item" id="toggle-show-all-nav">
                <span>🧭 Show All Nav Paths</span>
                <span class="item-check" id="chk-show-all-nav" style="display:none;">✓</span>
              </button>
              <button class="dropdown-item active" id="toggle-p2p">
                <span>📡 P2P Mesh Network</span>
                <span class="item-check" id="chk-p2p">✓</span>
              </button>
              <button class="dropdown-item active" id="toggle-traj">
                <span>📈 Horizon Trajectories</span>
                <span class="item-check" id="chk-traj">✓</span>
              </button>
              <button class="dropdown-item active" id="toggle-halos">
                <span>🛡️ Safety Halos & Cones</span>
                <span class="item-check" id="chk-halos">✓</span>
              </button>
            </div>
          </div>
        </div>

        <div class="nav-divider"></div>

        <!-- Cluster 3: Zoom, Inspectors & Modals -->
        <div class="nav-group-cluster">
          <!-- Zoomable Nav Control -->
          <div class="nav-dropdown-wrapper" id="zoom-dropdown-wrapper">
            <button class="nav-btn" id="btn-nav-zoom" title="Warehouse Zoom & Magnification Controls">
              <span>🔍</span>
              <span id="nav-zoom-label">Zoom: 100%</span>
              <svg class="chevron-icon" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>
            </button>
            <div class="nav-dropdown-menu" id="menu-nav-zoom" style="min-width: 170px;">
              <div class="dropdown-header">Zoom Presets</div>
              <button class="dropdown-item" data-zoom="0.6"><span>🔍 60% Overview</span></button>
              <button class="dropdown-item" data-zoom="0.8"><span>🔍 80% Wide</span></button>
              <button class="dropdown-item active" data-zoom="1.0"><span>🔍 100% Fit</span><span class="item-check" id="chk-zoom-100">✓</span></button>
              <button class="dropdown-item" data-zoom="1.25"><span>🔍 125% Close</span></button>
              <button class="dropdown-item" data-zoom="1.5"><span>🔍 150% Focus</span></button>
              <button class="dropdown-item" data-zoom="2.0"><span>🔍 200% Deep Inspect</span></button>
              <div class="dropdown-divider"></div>
              <button class="dropdown-item" id="btn-zoom-reset-dropdown"><span>🔄 Reset / Center Fit</span></button>
            </div>
          </div>

          <div class="ctrl-card">
            <button class="mini-btn btn-primary" id="btn-open-amr-editor" title="Open Manual Robot Inspector & Controller">✏️ Edit Robot</button>
            <button class="mini-btn" id="btn-open-system-config" title="Manually tune P2P comms radius, safety clearance, and battery drain rate">⚙️ Tuner</button>
            <button class="mini-btn" id="btn-open-layout-json" title="View, copy, or edit raw JSON floor obstacles and stations">📋 JSON</button>
          </div>
        </div>
      </nav>

      <main id="main-content">
        <!-- Interactive Canvas Viewport -->
        <section id="viewport-container">
          <canvas id="sim-canvas" style="display:none;"></canvas>
          <div id="root" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 0;"></div>

          <!-- Floating Viewport Zoom Controls -->
          <div class="canvas-zoom-controls">
            <button class="canvas-zoom-btn" id="btn-zoom-in" title="Zoom In (+ or Mouse Wheel Up)">+</button>
            <div class="canvas-zoom-indicator" id="viewport-zoom-indicator">100%</div>
            <button class="canvas-zoom-btn" id="btn-zoom-out" title="Zoom Out (- or Mouse Wheel Down)">−</button>
            <button class="canvas-zoom-btn" id="btn-zoom-reset" title="Reset Viewport to Default Fit" style="font-size:11px;">⟲</button>
            <button class="canvas-zoom-btn" id="btn-zoom-pan" title="Toggle Pan Mode (or hold Space / Middle Mouse Drag)" style="font-size:13px;">✋</button>
          </div>

          <!-- Bottom Scenario Presets & Legend -->
          <div class="canvas-bottom-bar">
            <div class="scenario-pills">
              <span class="title-tag">Test Scenarios:</span>
              <button class="mini-btn" id="scen-choke" title="Spawn head-on conflict in narrow corridor">1. Choke Point Standoff</button>
              <button class="mini-btn" id="scen-cross" title="All 4 AMRs converge on central intersection">2. 4-Way Crossroad</button>
              <button class="mini-btn" id="scen-spill" title="Drop obstacle right into active path">3. Dynamic Obstacle Spill</button>
              <button class="mini-btn" id="scen-batt" title="AMR drops to low battery and gains priority right-of-way">4. Low Battery Docking</button>
            </div>

            <div class="canvas-legend">
              <div class="legend-item"><span class="legend-circle" style="background:#06b6d4;"></span> AMR-01 Alpha</div>
              <div class="legend-item"><span class="legend-circle" style="background:#f59e0b;"></span> AMR-02 Beta</div>
              <div class="legend-item"><span class="legend-circle" style="background:#10b981;"></span> AMR-03 Gamma</div>
              <div class="legend-item"><span class="legend-circle" style="background:#a855f7;"></span> AMR-04 Delta</div>
              <div class="legend-item"><span class="legend-circle" style="background:#ef4444; border: 1px dashed #fff;"></span> Dynamic Obstacle</div>
            </div>
          </div>
        </section>

        <!-- Right HUD & Telemetry Sidebar -->
        <aside id="hud-sidebar">
          <div class="tab-header">
            <button class="tab-btn active" id="tab-btn-fleet" data-tab="fleet">Fleet Status</button>
            <button class="tab-btn" id="tab-btn-telemetry" data-tab="telemetry">P2P Telemetry Log</button>
            <button class="tab-btn" id="tab-btn-arch" data-tab="arch">Edge-AI Architecture</button>
          </div>

          <!-- Tab 1: Fleet Cards -->
          <div class="tab-pane" id="pane-fleet">
            <div id="fleet-card-list" style="display:flex; flex-direction:column; gap:10px;">
              <!-- Robot cards injected by JavaScript -->
            </div>
          </div>

          <!-- Tab 2: P2P Broadcast Bus Log -->
          <div class="tab-pane" id="pane-telemetry" style="display:none;">
            <div class="telemetry-container">
              <div class="log-toolbar">
                <span style="font-size:11px; font-weight:700; text-transform:uppercase; color:var(--text-secondary);">Decentralized Broadcast Stream</span>
                <div style="display:flex; gap:6px;">
                  <select id="log-filter" class="log-filter-select">
                    <option value="ALL">All Packets</option>
                    <option value="CONFLICT">Conflicts & Yields</option>
                    <option value="DETOUR">Path Replanning</option>
                    <option value="P2P">Peer Broadcasts</option>
                  </select>
                  <button class="mini-btn" id="btn-clear-log">Clear</button>
                </div>
              </div>

              <div id="telemetry-log">
                <!-- Log messages stream here -->
              </div>
            </div>
          </div>

          <!-- Tab 3: Architecture Breakdown -->
          <div class="tab-pane" id="pane-arch" style="display:none; flex-direction:column; gap:10px;">
            <!-- D3.js Real-Time Fleet Throughput Chart Card -->
            <div class="info-box" style="background: rgba(15, 23, 42, 0.95); border: 1px solid var(--border-bright);">
              <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:10px;">
                <div>
                  <h4 style="color:var(--accent-cyan); font-size:12px; margin-bottom:2px; display:flex; align-items:center; gap:6px;">
                    <svg style="width:14px; height:14px; fill:currentColor;" viewBox="0 0 24 24"><path d="M3.5 18.49l6-6.01 4 4L22 6.92l-1.41-1.41-7.09 7.97-4-4L2 16.99z"/></svg>
                    Real-Time Fleet Throughput (D3.js)
                  </h4>
                  <p style="font-size:10px; color:var(--text-muted); font-family:var(--font-mono);">Deliveries per minute (DPM) • Trailing 60s horizon</p>
                </div>
                <div style="display:flex; gap:10px; text-align:right;">
                  <div>
                    <span style="font-size:9px; color:var(--text-muted); font-family:var(--font-mono); display:block;">CURRENT</span>
                    <span id="d3-stat-current" style="font-size:13px; font-weight:700; font-family:var(--font-mono); color:var(--accent-cyan);">0.0</span>
                    <span style="font-size:8px; color:var(--text-muted); font-family:var(--font-mono);">DPM</span>
                  </div>
                  <div>
                    <span style="font-size:9px; color:var(--text-muted); font-family:var(--font-mono); display:block;">PEAK</span>
                    <span id="d3-stat-peak" style="font-size:13px; font-weight:700; font-family:var(--font-mono); color:var(--accent-emerald);">0.0</span>
                    <span style="font-size:8px; color:var(--text-muted); font-family:var(--font-mono);">DPM</span>
                  </div>
                  <div>
                    <span style="font-size:9px; color:var(--text-muted); font-family:var(--font-mono); display:block;">AVERAGE</span>
                    <span id="d3-stat-avg" style="font-size:13px; font-weight:700; font-family:var(--font-mono); color:var(--accent-amber);">0.0</span>
                    <span style="font-size:8px; color:var(--text-muted); font-family:var(--font-mono);">DPM</span>
                  </div>
                </div>
              </div>

              <div id="d3-chart-wrapper" style="width:100%; height:160px; position:relative; background:rgba(6,9,17,0.7); border-radius:6px; border:1px solid rgba(255,255,255,0.03);">
                <svg id="d3-throughput-svg" style="width:100%; height:100%; overflow:visible;"></svg>
                <div id="d3-chart-tooltip" style="position:absolute; display:none; pointer-events:none; background:rgba(15,23,42,0.95); border:1px solid var(--accent-cyan); border-radius:4px; padding:4px 8px; font-size:10px; font-family:var(--font-mono); color:#fff; transform:translate(-50%, -120%); z-index:10; box-shadow:0 2px 8px rgba(0,0,0,0.5);"></div>
              </div>
            </div>

            <div class="info-box">
              <h4>Edge-AI Distributed Coordination Protocol</h4>
              <p>Unlike legacy automated guided vehicles (AGVs) that rely on a central server with single points of failure, this system runs full decentralized peer-to-peer (P2P) negotiation directly on edge microcontrollers.</p>
            </div>

            <div class="info-box" style="margin-top:4px;">
              <h4>How It Works:</h4>
              <div class="flow-step">
                <strong>1. Space-Time Horizon Prediction:</strong>
                Each AMR computes its projected trajectory vector <code>[(x0, y0, t0), ..., (xn, yn, tn)]</code> up to 5 seconds into the future based on its kinematic constraints.
              </div>
              <div class="flow-step">
                <strong>2. P2P Neighborhood Broadcast:</strong>
                AMRs broadcast their space-time horizons over local ad-hoc radio (DSRC/C-V2X) to any neighbor within their 180px communication horizon.
              </div>
              <div class="flow-step">
                <strong>3. Deterministic Priority Deconfliction:</strong>
                When two horizons overlap within clearance distance, both AMRs calculate the same deterministic priority ranking:
                <br>• Emergency/Critical Battery: <strong>Priority 5</strong>
                <br>• High-Priority Express Cargo: <strong>Priority 4</strong>
                <br>• Loaded Transport: <strong>Priority 3</strong>
                <br>• Returning / Empty: <strong>Priority 2</strong>
                <br>• Tie-Breaker: Deterministic AMR-ID hash.
                <br>The lower-priority AMR proactively yields or slows down at the intersection entrance.
              </div>
              <div class="flow-step">
                <strong>4. Dynamic Local Obstacle Avoidance:</strong>
                On-board 2D LIDAR sensors continuously detect unknown obstacles (spills/dropped pallets) and dynamically invoke local A* replanning without contacting any central controller.
              </div>
            </div>
          </div>
        </aside>
      </main>
    </div>

    <!-- AMR Manual Inspector & Controller Modal -->
    <div id="modal-amr-inspector" class="modal-backdrop hidden">
      <div class="modal-box">
        <div class="modal-header">
          <h3>
            <svg style="width:16px; height:16px; fill:currentColor;" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>
            MANUAL AMR INSPECTOR & CONTROLLER
          </h3>
          <button class="modal-close-btn" id="btn-close-amr-modal">✕</button>
        </div>

        <!-- Robot Switcher Tabs -->
        <div style="display:flex; gap:6px;" id="amr-modal-tabs">
          <button class="amr-selector-tab active" data-id="AMR-01">AMR-01 Alpha</button>
          <button class="amr-selector-tab" data-id="AMR-02">AMR-02 Beta</button>
          <button class="amr-selector-tab" data-id="AMR-03">AMR-03 Gamma</button>
          <button class="amr-selector-tab" data-id="AMR-04">AMR-04 Delta</button>
        </div>

        <div class="modal-grid-2col">
          <!-- Column 1: Core Parameters & Overrides -->
          <div style="display:flex; flex-direction:column; gap:10px;">
            <div class="form-group">
              <label class="form-label">Robot Call-Sign & Name</label>
              <input type="text" id="edit-amr-name" class="form-input" />
            </div>

            <div class="form-group">
              <div class="form-label">
                <span>Battery Level</span>
                <span id="lbl-edit-amr-battery" style="color:var(--accent-cyan); font-weight:700;">85%</span>
              </div>
              <input type="range" id="edit-amr-battery" class="form-range" min="5" max="100" />
              <div class="badge-btn-group" style="margin-top:2px;">
                <button type="button" class="mini-btn" id="btn-batt-15">15% (Low)</button>
                <button type="button" class="mini-btn" id="btn-batt-50">50%</button>
                <button type="button" class="mini-btn" id="btn-batt-80">80%</button>
                <button type="button" class="mini-btn" id="btn-batt-100">100%</button>
              </div>
            </div>

            <div class="form-group">
              <div class="form-label">
                <span>Speed / Max Velocity</span>
                <span id="lbl-edit-amr-speed" style="color:var(--accent-cyan); font-weight:700;">3.2 m/s</span>
              </div>
              <input type="range" id="edit-amr-speed" class="form-range" min="15" max="110" />
            </div>

            <div class="form-group">
              <label class="form-label">State / Navigation Mode</label>
              <select id="edit-amr-state" class="form-select">
                <option value="NAVIGATING">NAVIGATING (Autonomous)</option>
                <option value="YIELDING">YIELDING (Inter-Robot Clearance)</option>
                <option value="DETOURING">DETOURING (Obstacle Avoidance)</option>
                <option value="CHARGING">CHARGING (Docked at Charger)</option>
                <option value="BLOCKED">BLOCKED / STOPPED (Halted)</option>
              </select>
            </div>

            <div class="form-group">
              <label class="form-label">Priority Tier & Rank</label>
              <select id="edit-amr-priority" class="form-select">
                <option value="5">Priority 5 - Emergency / Operator Override / Critical Battery</option>
                <option value="4">Priority 4 - High Priority Express Cargo</option>
                <option value="3">Priority 3 - Loaded Transport</option>
                <option value="2">Priority 2 - Empty Repositioning</option>
                <option value="1">Priority 1 - Low Priority Staging</option>
              </select>
            </div>

            <div class="form-group">
              <label class="form-label">Priority Reason / Description</label>
              <input type="text" id="edit-amr-priority-reason" class="form-input" placeholder="Manual Operator Override" />
            </div>

            <div style="display:flex; align-items:center; gap:8px; margin-top:2px;">
              <input type="checkbox" id="edit-amr-payload" style="cursor:pointer;" />
              <label for="edit-amr-payload" style="font-size:11px; cursor:pointer; color:var(--text-primary); font-family:var(--font-mono);">Carrying Heavy Pallet Cargo Box</label>
            </div>
          </div>

          <!-- Column 2: Navigation Dispatch & Teleop Drive Pad -->
          <div style="display:flex; flex-direction:column; gap:10px;">
            <div style="background:#060911; border:1px solid var(--border-subtle); border-radius:6px; padding:10px; display:flex; flex-direction:column; gap:8px;">
              <span style="font-size:10.5px; font-weight:700; color:var(--accent-cyan); font-family:var(--font-mono); text-transform:uppercase;">Station Dispatch</span>
              <select id="edit-amr-station-select" class="form-select"></select>
              <button id="btn-edit-dispatch-station" class="btn-primary mini-btn" style="justify-content:center;">Dispatch to Selected Station</button>
            </div>

            <div style="background:#060911; border:1px solid var(--border-subtle); border-radius:6px; padding:10px; display:flex; flex-direction:column; gap:8px;">
              <span style="font-size:10.5px; font-weight:700; color:var(--accent-emerald); font-family:var(--font-mono); text-transform:uppercase;">Coordinate Dispatch & Teleport</span>
              <div style="display:grid; grid-template-columns:1fr 1fr; gap:6px;">
                <input type="number" id="edit-amr-coord-x" class="form-input" placeholder="Target X" />
                <input type="number" id="edit-amr-coord-y" class="form-input" placeholder="Target Y" />
              </div>
              <div style="display:flex; gap:6px;">
                <button id="btn-edit-dispatch-coord" class="mini-btn" style="flex:1;">Set Target (X,Y)</button>
                <button id="btn-edit-teleport" class="mini-btn btn-danger" style="flex:1;">Teleport (X,Y)</button>
              </div>
            </div>

            <div style="display:flex; flex-direction:column; align-items:center; gap:6px;">
              <span style="font-size:10px; font-family:var(--font-mono); color:var(--text-muted); text-transform:uppercase;">Manual Drive Teleoperation</span>
              <div class="dpad-grid">
                <div></div>
                <button class="dpad-btn" id="dpad-fwd" title="Drive Forward">▲</button>
                <div></div>
                <button class="dpad-btn" id="dpad-left" title="Rotate Left">◀</button>
                <button class="dpad-btn" id="dpad-stop" title="Emergency Stop" style="color:#ef4444;">⏹</button>
                <button class="dpad-btn" id="dpad-right" title="Rotate Right">▶</button>
                <div></div>
                <button class="dpad-btn" id="dpad-back" title="Drive Reverse">▼</button>
                <div></div>
              </div>
            </div>
          </div>
        </div>

        <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px solid var(--border-subtle); padding-top:10px; margin-top:4px;">
          <span style="font-size:10px; color:var(--text-muted); font-family:var(--font-mono);">Changes update active AMR state immediately in memory and telemetry.</span>
          <div style="display:flex; gap:6px;">
            <button class="mini-btn" id="btn-cancel-amr-edits">Close</button>
            <button class="btn-primary mini-btn" id="btn-save-amr-edits">Apply & Save</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Manual System Config & Physics Tuner Modal -->
    <div id="modal-system-config" class="modal-backdrop hidden">
      <div class="modal-box" style="max-width:540px;">
        <div class="modal-header">
          <h3>
            <svg style="width:16px; height:16px; fill:currentColor;" viewBox="0 0 24 24"><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg>
            MANUAL SIMULATION & P2P PROTOCOL TUNER
          </h3>
          <button class="modal-close-btn" id="btn-close-config-modal">✕</button>
        </div>

        <p style="font-size:11px; color:var(--text-secondary); line-height:1.5;">
          Manually tweak the distributed edge coordination protocol, communication envelopes, safety bubbles, and power consumption rates in real time.
        </p>

        <div style="display:flex; flex-direction:column; gap:12px;">
          <div class="form-group">
            <div class="form-label">
              <span>P2P Communication Horizon Range</span>
              <span id="lbl-cfg-comms" style="color:var(--accent-cyan); font-weight:700;">180 px</span>
            </div>
            <input type="range" id="cfg-comms" class="form-range" min="80" max="380" step="5" value="180" />
            <span style="font-size:9.5px; color:var(--text-muted);">Radius of direct ad-hoc peer-to-peer V2V radio broadcast.</span>
          </div>

          <div class="form-group">
            <div class="form-label">
              <span>Collision Safety Buffer Radius</span>
              <span id="lbl-cfg-safety" style="color:var(--accent-cyan); font-weight:700;">26 px</span>
            </div>
            <input type="range" id="cfg-safety" class="form-range" min="16" max="50" step="1" value="26" />
            <span style="font-size:9.5px; color:var(--text-muted);">Physical clearance safety bubble around each robot chassis.</span>
          </div>

          <div class="form-group">
            <div class="form-label">
              <span>Space-Time Yield Clearance Threshold</span>
              <span id="lbl-cfg-yield" style="color:var(--accent-cyan); font-weight:700;">44 px</span>
            </div>
            <input type="range" id="cfg-yield" class="form-range" min="20" max="80" step="2" value="44" />
            <span style="font-size:9.5px; color:var(--text-muted);">Minimum projected proximity between trajectory horizons before yielding is triggered.</span>
          </div>

          <div class="form-group">
            <div class="form-label">
              <span>Space-Time Prediction Horizon Duration</span>
              <span id="lbl-cfg-horizon" style="color:var(--accent-cyan); font-weight:700;">4.5 s</span>
            </div>
            <input type="range" id="cfg-horizon" class="form-range" min="1.5" max="8.0" step="0.5" value="4.5" />
            <span style="font-size:9.5px; color:var(--text-muted);">Future trajectory look-ahead time window computed by kinematics.</span>
          </div>

          <div class="form-group">
            <div class="form-label">
              <span>Battery Discharge Rate Multiplier</span>
              <span id="lbl-cfg-battery" style="color:var(--accent-cyan); font-weight:700;">1.0x</span>
            </div>
            <input type="range" id="cfg-battery" class="form-range" min="0" max="4.0" step="0.25" value="1.0" />
            <span style="font-size:9.5px; color:var(--text-muted);">Set to 0x for infinite power, or 2x-4x to test frequent low-battery charging cycles.</span>
          </div>
        </div>

        <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px solid var(--border-subtle); padding-top:10px;">
          <button class="mini-btn btn-danger" id="btn-reset-sys-config">Restore Defaults</button>
          <div style="display:flex; gap:6px;">
            <button class="mini-btn" id="btn-cancel-sys-config">Cancel</button>
            <button class="btn-primary mini-btn" id="btn-apply-sys-config">Apply Configuration</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Raw Layout JSON Editor Modal -->
    <div id="modal-layout-json" class="modal-backdrop hidden">
      <div class="modal-box" style="max-width:600px;">
        <div class="modal-header">
          <h3>
            <svg style="width:16px; height:16px; fill:currentColor;" viewBox="0 0 24 24"><path d="M9.4 16.6L4.8 12l4.6-4.6L8 6l-6 6 6 6 1.4-1.4zm5.2 0l4.6-4.6-4.6-4.6L16 6l6 6-6 6-1.4-1.4z"/></svg>
            MANUAL FLOOR LAYOUT JSON EDITOR
          </h3>
          <button class="modal-close-btn" id="btn-close-json-modal">✕</button>
        </div>

        <p style="font-size:11px; color:var(--text-secondary); line-height:1.5;">
          Directly inspect, edit, copy, or paste raw JSON data representing active dynamic obstacle grid indices and custom stations.
        </p>

        <textarea id="txt-layout-json" rows="12" style="background:#04070e; border:1px solid var(--border-subtle); border-radius:6px; padding:8px 10px; font-family:var(--font-mono); font-size:11px; color:var(--accent-cyan); resize:vertical; width:100%; box-sizing:border-box;"></textarea>

        <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px solid var(--border-subtle); padding-top:10px;">
          <div style="display:flex; gap:6px;">
            <button class="mini-btn" id="btn-copy-json">Copy to Clipboard</button>
            <button class="mini-btn" id="btn-download-json">Download .json</button>
          </div>
          <div style="display:flex; gap:6px;">
            <button class="mini-btn" id="btn-cancel-json">Close</button>
            <button class="btn-primary mini-btn" id="btn-apply-json">Load & Apply JSON</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Custom Station Dialog Modal -->
    <div id="modal-add-station" class="modal-backdrop hidden">
      <div class="modal-box" style="max-width:440px;">
        <div class="modal-header">
          <h3>
            <svg style="width:16px; height:16px; fill:currentColor;" viewBox="0 0 24 24"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg>
            ADD CUSTOM WAREHOUSE STATION
          </h3>
          <button class="modal-close-btn" id="btn-close-station-modal">✕</button>
        </div>

        <div style="display:flex; flex-direction:column; gap:10px;">
          <div class="form-group">
            <label class="form-label">Station Name / Label</label>
            <input type="text" id="new-station-name" class="form-input" placeholder="e.g. Staging Dock 4" />
          </div>

          <div class="form-group">
            <label class="form-label">Station Type</label>
            <select id="new-station-type" class="form-select">
              <option value="pickup">Inbound Pickup Bay</option>
              <option value="dropoff">Outbound Packing Dock</option>
              <option value="charge">Automated Fast Charger</option>
              <option value="waypoint">Corridor Waypoint Junction</option>
            </select>
          </div>

          <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
            <div class="form-group">
              <label class="form-label">Grid Column</label>
              <input type="number" id="new-station-col" class="form-input" readonly />
            </div>
            <div class="form-group">
              <label class="form-label">Grid Row</label>
              <input type="number" id="new-station-row" class="form-input" readonly />
            </div>
          </div>
        </div>

        <div style="display:flex; justify-content:flex-end; gap:6px; border-top:1px solid var(--border-subtle); padding-top:10px;">
          <button class="mini-btn" id="btn-cancel-station">Cancel</button>
          <button class="btn-primary mini-btn" id="btn-save-station">Place Station</button>
        </div>
      </div>
    </div>

    <!-- Complete Simulation Engine Script -->
    <script>
      (function () {
        'use strict';

        // --- SOUND SYNTHESIZER (Web Audio API - zero dependencies) ---
        let audioCtx = null;
        let soundEnabled = false;

        function initAudio() {
          if (!audioCtx) {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            if (AudioContext) {
              audioCtx = new AudioContext();
            }
          }
          if (audioCtx && audioCtx.state === 'suspended') {
            audioCtx.resume();
          }
        }

        function playTone(freq, type, duration, gainVal = 0.05) {
          if (!soundEnabled || !audioCtx) return;
          try {
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.type = type;
            osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
            gain.gain.setValueAtTime(gainVal, audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + duration);
            osc.connect(gain);
            gain.connect(audioCtx.destination);
            osc.start();
            osc.stop(audioCtx.currentTime + duration);
          } catch (e) {
            // Audio context safely ignored if blocked
          }
        }

        function playConflictBeep() {
          playTone(520, 'sine', 0.12, 0.04);
          setTimeout(() => playTone(680, 'sine', 0.15, 0.04), 80);
        }

        function playObstacleBeep() {
          playTone(280, 'triangle', 0.2, 0.06);
        }

        function playCompleteBeep() {
          playTone(600, 'sine', 0.1, 0.03);
          setTimeout(() => playTone(880, 'sine', 0.18, 0.03), 100);
        }

        // --- SIMULATION CONFIG & CONSTANTS ---
        const WORLD_W = 1200;
        const WORLD_H = 800;
        const CELL_SIZE = 25; // 48 x 32 grid cells
        const GRID_COLS = Math.floor(WORLD_W / CELL_SIZE);
        const GRID_ROWS = Math.floor(WORLD_H / CELL_SIZE);

        // Mutable System & Physics Parameters (modifiable via Manual Tuner & JSON)
        let COMMS_RADIUS = 180; // P2P radio broadcast range
        let SAFETY_RADIUS = 26; // Hard collision bubble
        let YIELD_CLEARANCE = 44; // Space-time conflict trigger distance
        let HORIZON_SECONDS = 4.5;
        const HORIZON_STEPS = 12;
        let BATTERY_DRAIN_MULTIPLIER = 1.0;

        // Interactive Tool Mode
        let activeTool = 'select'; // 'select' | 'target' | 'draw' | 'erase' | 'station' | 'teleport'
        let isPointerDragging = false;
        let pendingStationPos = { col: 0, row: 0, x: 0, y: 0 };

        // --- GRID & WAREHOUSE ENVIRONMENT ---
        // 0: Free floor, 1: Static Shelf/Wall, 2: Dynamic Obstacle
        const grid = new Uint8Array(GRID_COLS * GRID_ROWS);

        function gridIndex(c, r) {
          return r * GRID_COLS + c;
        }

        function isBlocked(c, r) {
          if (c < 1 || c >= GRID_COLS - 1 || r < 1 || r >= GRID_ROWS - 1) return true;
          return grid[gridIndex(c, r)] > 0;
        }

        // Warehouse Racks definition (in grid cells)
        const racks = [
          // Shelf Block A (Top Left)
          { c1: 6, r1: 4, c2: 12, r2: 8, label: 'RACK A1' },
          { c1: 15, r1: 4, c2: 21, r2: 8, label: 'RACK A2' },
          // Shelf Block B (Mid Left)
          { c1: 6, r1: 12, c2: 12, r2: 16, label: 'RACK B1' },
          { c1: 15, r1: 12, c2: 21, r2: 16, label: 'RACK B2' },
          // Shelf Block C (Bottom Left)
          { c1: 6, r1: 20, c2: 12, r2: 24, label: 'RACK C1' },
          { c1: 15, r1: 20, c2: 21, r2: 24, label: 'RACK C2' },

          // Shelf Block D (Top Right)
          { c1: 27, r1: 4, c2: 33, r2: 8, label: 'RACK D1' },
          { c1: 36, r1: 4, c2: 42, r2: 8, label: 'RACK D2' },
          // Shelf Block E (Mid Right)
          { c1: 27, r1: 12, c2: 33, r2: 16, label: 'RACK E1' },
          { c1: 36, r1: 12, c2: 42, r2: 16, label: 'RACK E2' },
          // Shelf Block F (Bottom Right)
          { c1: 27, r1: 20, c2: 33, r2: 24, label: 'RACK F1' },
          { c1: 36, r1: 20, c2: 42, r2: 24, label: 'RACK F2' },
        ];

        // Populate static racks into grid
        racks.forEach(rack => {
          for (let c = rack.c1; c <= rack.c2; c++) {
            for (let r = rack.r1; r <= rack.r2; r++) {
              grid[gridIndex(c, r)] = 1;
            }
          }
        });

        // Stations
        const STATIONS = {
          PICKUP_1: { name: 'Inbound Bay 1', x: 2 * CELL_SIZE + 12, y: 6 * CELL_SIZE + 12, type: 'pickup', col: 2, row: 6 },
          PICKUP_2: { name: 'Inbound Bay 2', x: 2 * CELL_SIZE + 12, y: 14 * CELL_SIZE + 12, type: 'pickup', col: 2, row: 14 },
          PICKUP_3: { name: 'Inbound Bay 3', x: 2 * CELL_SIZE + 12, y: 22 * CELL_SIZE + 12, type: 'pickup', col: 2, row: 22 },

          DROPOFF_1: { name: 'Packing Dock 1', x: 45 * CELL_SIZE + 12, y: 6 * CELL_SIZE + 12, type: 'dropoff', col: 45, row: 6 },
          DROPOFF_2: { name: 'Packing Dock 2', x: 45 * CELL_SIZE + 12, y: 14 * CELL_SIZE + 12, type: 'dropoff', col: 45, row: 14 },
          DROPOFF_3: { name: 'Packing Dock 3', x: 45 * CELL_SIZE + 12, y: 22 * CELL_SIZE + 12, type: 'dropoff', col: 45, row: 22 },

          CHARGE_1: { name: 'Fast Charger 1', x: 18 * CELL_SIZE + 12, y: 29 * CELL_SIZE + 12, type: 'charge', col: 18, row: 29 },
          CHARGE_2: { name: 'Fast Charger 2', x: 30 * CELL_SIZE + 12, y: 29 * CELL_SIZE + 12, type: 'charge', col: 30, row: 29 },

          JUNCTION_CENTRAL: { name: 'Main Crossroads', x: 24 * CELL_SIZE + 12, y: 14 * CELL_SIZE + 12, type: 'waypoint', col: 24, row: 14 }
        };

        // --- DYNAMIC OBSTACLES ---
        const dynamicObstacles = new Set(); // set of gridIndex

        function toggleObstacleAtWorldPos(wx, wy) {
          const c = Math.floor(wx / CELL_SIZE);
          const r = Math.floor(wy / CELL_SIZE);
          if (c < 1 || c >= GRID_COLS - 1 || r < 1 || r >= GRID_ROWS - 1) return;

          const idx = gridIndex(c, r);
          if (grid[idx] === 1) return; // Cannot place on static shelves

          if (dynamicObstacles.has(idx)) {
            dynamicObstacles.delete(idx);
            grid[idx] = 0;
            addTelemetry('OBSTACLE', `Obstacle removed at (${c * CELL_SIZE}, ${r * CELL_SIZE})`);
          } else {
            dynamicObstacles.add(idx);
            grid[idx] = 2;
            playObstacleBeep();
            addTelemetry('OBSTACLE', `Dynamic obstacle placed at Grid[${c},${r}] (Cell: ${c * CELL_SIZE},${r * CELL_SIZE})`);
            
            // Check if any AMR is affected and trigger local dynamic replanning
            fleet.forEach(amr => {
              const d = Math.hypot(amr.x - (c * CELL_SIZE + CELL_SIZE / 2), amr.y - (r * CELL_SIZE + CELL_SIZE / 2));
              if (d < 220) {
                amr.handleObstacleDetected(c, r);
              }
            });
          }
        }

        function clearAllObstacles() {
          dynamicObstacles.forEach(idx => {
            grid[idx] = 0;
          });
          dynamicObstacles.clear();
          addTelemetry('OBSTACLE', 'All dynamic floor obstacles cleared.');
          fleet.forEach(amr => amr.replan());
        }

        // --- PATHFINDING: A* WITH SAFETY MARGINS & DIAGONALS ---
        function findPath(startCol, startRow, targetCol, targetRow, avoidDynamicIndices = null) {
          if (startCol === targetCol && startRow === targetRow) {
            return [{ c: targetCol, r: targetRow, x: targetCol * CELL_SIZE + CELL_SIZE / 2, y: targetRow * CELL_SIZE + CELL_SIZE / 2 }];
          }

          // Open set: min-heap or priority list
          const openList = [];
          const closedSet = new Uint8Array(GRID_COLS * GRID_ROWS);
          const gScore = new Float32Array(GRID_COLS * GRID_ROWS).fill(1e9);
          const parent = new Int32Array(GRID_COLS * GRID_ROWS).fill(-1);

          const startIdx = gridIndex(startCol, startRow);
          const targetIdx = gridIndex(targetCol, targetRow);

          gScore[startIdx] = 0;
          const hStart = Math.hypot(targetCol - startCol, targetRow - startRow);
          openList.push({ idx: startIdx, c: startCol, r: startRow, f: hStart });

          const neighbors = [
            { dc: 1, dr: 0, cost: 1.0 },
            { dc: -1, dr: 0, cost: 1.0 },
            { dc: 0, dr: 1, cost: 1.0 },
            { dc: 0, dr: -1, cost: 1.0 },
            // Diagonals with slightly higher cost
            { dc: 1, dr: 1, cost: 1.414 },
            { dc: -1, dr: 1, cost: 1.414 },
            { dc: 1, dr: -1, cost: 1.414 },
            { dc: -1, dr: -1, cost: 1.414 },
          ];

          let iterations = 0;
          const maxIterations = 2500;

          while (openList.length > 0 && iterations++ < maxIterations) {
            // Find lowest f
            let bestIndex = 0;
            for (let i = 1; i < openList.length; i++) {
              if (openList[i].f < openList[bestIndex].f) bestIndex = i;
            }
            const current = openList.splice(bestIndex, 1)[0];

            if (current.idx === targetIdx) {
              // Reconstruct path
              const path = [];
              let currIdx = targetIdx;
              while (currIdx !== -1) {
                const c = currIdx % GRID_COLS;
                const r = Math.floor(currIdx / GRID_COLS);
                path.push({ c, r, x: c * CELL_SIZE + CELL_SIZE / 2, y: r * CELL_SIZE + CELL_SIZE / 2 });
                currIdx = parent[currIdx];
              }
              path.reverse();
              return smoothPath(path);
            }

            closedSet[current.idx] = 1;

            for (let n of neighbors) {
              const nc = current.c + n.dc;
              const nr = current.r + n.dr;

              if (nc < 1 || nc >= GRID_COLS - 1 || nr < 1 || nr >= GRID_ROWS - 1) continue;
              const nIdx = gridIndex(nc, nr);

              if (closedSet[nIdx]) continue;

              // Check obstacle
              if (grid[nIdx] > 0 && nIdx !== targetIdx) continue;
              if (avoidDynamicIndices && avoidDynamicIndices.has(nIdx) && nIdx !== targetIdx) continue;

              // For diagonal movement, ensure no corner cutting through walls
              if (n.dc !== 0 && n.dr !== 0) {
                if (grid[gridIndex(current.c + n.dc, current.r)] > 0 || grid[gridIndex(current.c, current.r + n.dr)] > 0) {
                  continue;
                }
              }

              // Extra clearance penalty near rack corners for smooth robotic turns
              let clearancePenalty = 0;
              if (isBlocked(nc + 1, nr) || isBlocked(nc - 1, nr) || isBlocked(nc, nr + 1) || isBlocked(nc, nr - 1)) {
                clearancePenalty = 0.5;
              }

              const tentativeG = gScore[current.idx] + n.cost + clearancePenalty;
              if (tentativeG < gScore[nIdx]) {
                parent[nIdx] = current.idx;
                gScore[nIdx] = tentativeG;
                const h = Math.hypot(targetCol - nc, targetRow - nr);
                const f = tentativeG + h;

                const existing = openList.find(item => item.idx === nIdx);
                if (existing) {
                  existing.f = f;
                } else {
                  openList.push({ idx: nIdx, c: nc, r: nr, f });
                }
              }
            }
          }

          // Fallback if target unreached: return direct or empty
          return [];
        }

        // Line-of-sight path smoother for clean continuous AMR navigation
        function smoothPath(rawPath) {
          if (rawPath.length <= 2) return rawPath;
          const smoothed = [rawPath[0]];
          let currentIdx = 0;

          while (currentIdx < rawPath.length - 1) {
            let furthest = currentIdx + 1;
            for (let check = currentIdx + 2; check < rawPath.length; check++) {
              if (hasLineOfSight(rawPath[currentIdx].x, rawPath[currentIdx].y, rawPath[check].x, rawPath[check].y)) {
                furthest = check;
              } else {
                break;
              }
            }
            smoothed.push(rawPath[furthest]);
            currentIdx = furthest;
          }
          return smoothed;
        }

        function hasLineOfSight(x0, y0, x1, y1) {
          const steps = Math.ceil(Math.hypot(x1 - x0, y1 - y0) / (CELL_SIZE * 0.4));
          for (let i = 1; i < steps; i++) {
            const t = i / steps;
            const px = x0 + (x1 - x0) * t;
            const py = y0 + (y1 - y0) * t;
            const c = Math.floor(px / CELL_SIZE);
            const r = Math.floor(py / CELL_SIZE);
            if (grid[gridIndex(c, r)] > 0) return false;
          }
          return true;
        }

        // --- AUTONOMOUS MOBILE ROBOT (AMR) CLASS ---
        let nextRobotUniqueId = 1;

        class AMR {
          constructor(config) {
            this.id = config.id;
            this.name = config.name;
            this.color = config.color;
            this.accent = config.accent;
            
            // Physics / Pose
            this.x = config.initialX;
            this.y = config.initialY;
            this.heading = config.initialHeading || 0; // radians
            this.speed = 0;
            this.maxSpeed = config.maxSpeed || 65; // px per sec
            this.turnRate = 4.5; // rad/sec
            
            // State: NAVIGATING, YIELDING, DETOURING, BLOCKED, CHARGING, DOCKED
            this.state = 'NAVIGATING';
            this.statusReason = 'Routine Logistics';
            
            // Priorities:
            // 5: Low Battery Critical
            // 4: Rush High-Priority Delivery
            // 3: Loaded Cargo Transport
            // 2: Empty Repositioning
            // 1: Low Priority Staging
            this.basePriority = config.basePriority || 3;
            this.priority = this.basePriority;
            this.priorityReason = 'Standard Mission';
            
            // Mission & Battery
            this.battery = config.battery || 85; // percentage
            this.carryingPayload = config.carryingPayload || false;
            this.payloadType = 'Smart Tote';
            this.deliveriesCompleted = 0;
            this.deconflictionsCount = 0;
            this.collisionsCount = 0;
            
            // Navigation
            this.currentTargetStation = null;
            this.path = [];
            this.pathIndex = 0;
            this.predictedHorizon = []; // Space-time horizon: [{ x, y, t, heading }]
            
            // P2P Deconfliction Engine
            this.yieldingTo = null; // AMR instance
            this.yieldTimer = 0;
            this.yieldDuration = 0;
            this.spaceTimeConflictPoint = null; // { x, y, timeToConflict, peerId }
            this.peersInRange = new Set();
            this.tempAvoidArea = new Set();
            
            // Initial task assignment
            this.assignNextTask(config.initialDestination);
          }

          assignNextTask(forcedStation = null) {
            if (this.battery < 22) {
              // Emergency Charging Docking
              const charger = Math.random() > 0.5 ? STATIONS.CHARGE_1 : STATIONS.CHARGE_2;
              this.currentTargetStation = charger;
              this.priority = 5;
              this.priorityReason = 'Critical Battery Override';
              this.statusReason = 'En Route to Charger';
              addTelemetry('BATTERY', `${this.id} low battery (${Math.round(this.battery)}%). Priority elevated to P5 (Emergency Dock).`);
            } else if (forcedStation) {
              this.currentTargetStation = forcedStation;
              this.statusReason = `Moving to ${forcedStation.name}`;
            } else {
              // Standard cycle: Pickup -> Dropoff
              if (!this.carryingPayload) {
                const pickups = [STATIONS.PICKUP_1, STATIONS.PICKUP_2, STATIONS.PICKUP_3];
                this.currentTargetStation = pickups[Math.floor(Math.random() * pickups.length)];
                this.priority = 2;
                this.priorityReason = 'Empty Relocation';
                this.statusReason = `Heading to ${this.currentTargetStation.name}`;
              } else {
                const dropoffs = [STATIONS.DROPOFF_1, STATIONS.DROPOFF_2, STATIONS.DROPOFF_3];
                this.currentTargetStation = dropoffs[Math.floor(Math.random() * dropoffs.length)];
                // Randomly assign rush priority to some missions
                const isRush = Math.random() < 0.25;
                this.priority = isRush ? 4 : 3;
                this.priorityReason = isRush ? 'Express Rush Order' : 'Standard Loaded Transport';
                this.statusReason = `Delivering to ${this.currentTargetStation.name}`;
              }
            }

            this.replan();
          }

          replan() {
            if (!this.currentTargetStation) return;
            const startCol = Math.max(1, Math.min(GRID_COLS - 2, Math.floor(this.x / CELL_SIZE)));
            const startRow = Math.max(1, Math.min(GRID_ROWS - 2, Math.floor(this.y / CELL_SIZE)));
            
            const newPath = findPath(startCol, startRow, this.currentTargetStation.col, this.currentTargetStation.row, this.tempAvoidArea);
            if (newPath.length > 0) {
              this.path = newPath;
              this.pathIndex = 0;
              this.state = 'NAVIGATING';
              this.spaceTimeConflictPoint = null;
            } else {
              this.state = 'BLOCKED';
              this.statusReason = 'Path completely obstructed';
            }
            this.updatePredictedHorizon();
          }

          handleObstacleDetected(col, row) {
            // Check if this obstacle sits along upcoming path
            for (let i = this.pathIndex; i < Math.min(this.pathIndex + 6, this.path.length); i++) {
              const wp = this.path[i];
              const d = Math.hypot(wp.x - (col * CELL_SIZE + CELL_SIZE / 2), wp.y - (row * CELL_SIZE + CELL_SIZE / 2));
              if (d < CELL_SIZE * 1.8) {
                this.state = 'DETOURING';
                this.statusReason = 'Dynamic Obstacle Avoidance';
                addTelemetry('DETOUR', `${this.id} on-board LIDAR detected floor spill at Grid[${col},${row}]. Local A* replan triggered.`);
                this.replan();
                return;
              }
            }
          }

          updatePredictedHorizon() {
            this.predictedHorizon = [];
            if (!this.path || this.pathIndex >= this.path.length) {
              this.predictedHorizon.push({ x: this.x, y: this.y, t: 0, heading: this.heading });
              return;
            }

            let currX = this.x;
            let currY = this.y;
            let accumulatedDist = 0;
            let currentPathIdx = this.pathIndex;

            this.predictedHorizon.push({ x: currX, y: currY, t: 0, heading: this.heading });

            const estSpeed = Math.max(25, this.speed > 5 ? this.speed : this.maxSpeed * 0.85);

            for (let step = 1; step <= HORIZON_STEPS; step++) {
              const targetTime = (step / HORIZON_STEPS) * HORIZON_SECONDS;
              const targetDist = targetTime * estSpeed;

              // Step forward along path until targetDist is reached
              while (currentPathIdx < this.path.length) {
                const targetWp = this.path[currentPathIdx];
                const segDist = Math.hypot(targetWp.x - currX, targetWp.y - currY);
                if (accumulatedDist + segDist >= targetDist) {
                  const rem = targetDist - accumulatedDist;
                  const ratio = segDist > 0.001 ? rem / segDist : 0;
                  const projX = currX + (targetWp.x - currX) * ratio;
                  const projY = currY + (targetWp.y - currY) * ratio;
                  const projHeading = Math.atan2(targetWp.y - currY, targetWp.x - currX);
                  this.predictedHorizon.push({ x: projX, y: projY, t: targetTime, heading: projHeading });
                  break;
                } else {
                  accumulatedDist += segDist;
                  currX = targetWp.x;
                  currY = targetWp.y;
                  currentPathIdx++;
                }
              }

              if (currentPathIdx >= this.path.length) {
                // Past end of path, stay at goal
                const lastWp = this.path[this.path.length - 1] || { x: this.x, y: this.y };
                this.predictedHorizon.push({ x: lastWp.x, y: lastWp.y, t: targetTime, heading: this.heading });
              }
            }
          }

          // --- P2P DECONFLICTION STEP ---
          evaluateP2PBroadcast(peers) {
            this.peersInRange.clear();
            let activeConflict = null;

            for (let peer of peers) {
              if (peer === this) continue;
              const dist = Math.hypot(peer.x - this.x, peer.y - this.y);
              if (dist <= COMMS_RADIUS) {
                this.peersInRange.add(peer);
                // Check future space-time trajectory overlap
                const conflict = this.detectSpaceTimeConflict(peer);
                if (conflict) {
                  activeConflict = conflict;
                }
              }
            }

            if (activeConflict) {
              const peer = activeConflict.peer;
              const conflictTime = activeConflict.time;
              const conflictLoc = activeConflict.loc;

              // Deterministic priority calculation:
              // Higher score wins right of way. Tie-breaker: lexicographical ID comparison
              const myRank = this.priority * 100 + (this.id.charCodeAt(4) || 0);
              const peerRank = peer.priority * 100 + (peer.id.charCodeAt(4) || 0);

              if (myRank < peerRank) {
                // We are LOWER priority -> WE YIELD
                if (this.state !== 'YIELDING') {
                  this.state = 'YIELDING';
                  this.yieldingTo = peer;
                  this.statusReason = `Yielding to ${peer.name} (Pri: ${this.priority} < ${peer.priority})`;
                  this.yieldTimer = 0;
                  this.deconflictionsCount++;
                  playConflictBeep();
                  addTelemetry('DECONFLICT', `[SPACE-TIME CONFLICT] ${this.id} yields to ${peer.id} at (${Math.round(conflictLoc.x)}, ${Math.round(conflictLoc.y)}) t=${conflictTime.toFixed(1)}s [P${this.priority} < P${peer.priority}]`);
                }
                this.spaceTimeConflictPoint = { ...conflictLoc, time: conflictTime, peerId: peer.id };
              } else {
                // We are HIGHER priority -> MAINTAIN RIGHT OF WAY
                if (this.state === 'YIELDING' && this.yieldingTo === peer) {
                  this.state = 'NAVIGATING';
                  this.yieldingTo = null;
                }
                this.spaceTimeConflictPoint = { ...conflictLoc, time: conflictTime, peerId: peer.id };
                this.statusReason = `Right-of-Way over ${peer.name}`;
              }
            } else {
              // No space-time conflict detected
              if (this.state === 'YIELDING') {
                this.yieldTimer += 0.1;
                // Wait until peer has cleared or yield timeout
                if (!this.yieldingTo || Math.hypot(this.yieldingTo.x - this.x, this.yieldingTo.y - this.y) > YIELD_CLEARANCE * 1.5 || this.yieldTimer > 2.0) {
                  this.state = 'NAVIGATING';
                  this.yieldingTo = null;
                  this.spaceTimeConflictPoint = null;
                  this.statusReason = 'Cleared intersection; resuming track';
                }
              } else if (this.state !== 'CHARGING' && this.state !== 'BLOCKED') {
                this.spaceTimeConflictPoint = null;
              }
            }
          }

          detectSpaceTimeConflict(peer) {
            if (!this.predictedHorizon || !peer.predictedHorizon) return null;
            const count = Math.min(this.predictedHorizon.length, peer.predictedHorizon.length);

            for (let i = 1; i < count; i++) {
              const myPos = this.predictedHorizon[i];
              const peerPos = peer.predictedHorizon[i];
              const dist = Math.hypot(myPos.x - peerPos.x, myPos.y - peerPos.y);

              if (dist < YIELD_CLEARANCE) {
                return {
                  peer: peer,
                  time: myPos.t,
                  loc: { x: (myPos.x + peerPos.x) / 2, y: (myPos.y + peerPos.y) / 2 }
                };
              }
            }
            return null;
          }

          // --- KINEMATICS & MOVEMENT UPDATE ---
          update(dt) {
            // Battery drain / recharge
            if (this.state === 'CHARGING') {
              this.battery = Math.min(100, this.battery + dt * 3.5);
              if (this.battery >= 98) {
                this.state = 'NAVIGATING';
                this.priority = this.basePriority;
                this.priorityReason = 'Routine Logistics';
                addTelemetry('BATTERY', `${this.id} fully charged. Resuming logistics duties.`);
                this.assignNextTask();
              }
              return;
            } else {
              this.battery = Math.max(5, this.battery - dt * 0.16 * BATTERY_DRAIN_MULTIPLIER);
              if (this.battery < 20 && this.priority < 5 && this.currentTargetStation?.type !== 'charge') {
                this.assignNextTask();
              }
            }

            // If yielding: decelerate smoothly to zero
            if (this.state === 'YIELDING') {
              this.speed = Math.max(0, this.speed - dt * 60);
              this.yieldTimer += dt;
              // If stuck in yield for too long, execute dynamic detour around conflict point
              if (this.yieldTimer > 3.2) {
                addTelemetry('DETOUR', `${this.id} standoff duration exceeded 3.2s. Computing dynamic detour corridor.`);
                this.state = 'DETOURING';
                this.statusReason = 'Taking alternate detour';
                // Add temporary cost to current next waypoint to force detour
                if (this.path[this.pathIndex]) {
                  const wp = this.path[this.pathIndex];
                  this.tempAvoidArea.add(gridIndex(Math.floor(wp.x / CELL_SIZE), Math.floor(wp.y / CELL_SIZE)));
                  this.replan();
                  setTimeout(() => this.tempAvoidArea.clear(), 6000);
                }
              }
              return;
            }

            if (!this.path || this.pathIndex >= this.path.length) {
              this.speed = 0;
              // Check if reached station
              if (this.currentTargetStation) {
                const distToGoal = Math.hypot(this.currentTargetStation.x - this.x, this.currentTargetStation.y - this.y);
                if (distToGoal < CELL_SIZE * 1.5) {
                  this.onStationReached();
                }
              }
              return;
            }

            // Normal Navigation along path
            const target = this.path[this.pathIndex];
            const dx = target.x - this.x;
            const dy = target.y - this.y;
            const dist = Math.hypot(dx, dy);

            if (dist < 12) {
              this.pathIndex++;
              if (this.pathIndex >= this.path.length) {
                this.onStationReached();
                return;
              }
            }

            // Desired heading
            const desiredHeading = Math.atan2(dy, dx);
            let angleDiff = desiredHeading - this.heading;
            while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;
            while (angleDiff < -Math.PI) angleDiff += Math.PI * 2;

            // Turn smoothly toward waypoint
            const turnStep = this.turnRate * dt;
            if (Math.abs(angleDiff) < turnStep) {
              this.heading = desiredHeading;
            } else {
              this.heading += Math.sign(angleDiff) * turnStep;
            }

            // Align speed with heading error (slow down during sharp turns)
            const alignmentFactor = Math.max(0.2, Math.cos(angleDiff));
            const targetSpeed = this.maxSpeed * alignmentFactor;

            // Accelerate / decelerate
            if (this.speed < targetSpeed) {
              this.speed = Math.min(targetSpeed, this.speed + dt * 45);
            } else {
              this.speed = Math.max(targetSpeed, this.speed - dt * 55);
            }

            // Move forward
            this.x += Math.cos(this.heading) * this.speed * dt;
            this.y += Math.sin(this.heading) * this.speed * dt;

            this.updatePredictedHorizon();
          }

          onStationReached() {
            if (!this.currentTargetStation) return;

            if (this.currentTargetStation.type === 'charge') {
              this.state = 'CHARGING';
              this.statusReason = 'Inductive High-Power Fast Charging';
              addTelemetry('BATTERY', `${this.id} docked at ${this.currentTargetStation.name}. Recharging...`);
            } else if (this.currentTargetStation.type === 'pickup') {
              this.carryingPayload = true;
              this.statusReason = 'Loaded smart tote; transferring to dropoff';
              playCompleteBeep();
              addTelemetry('MISSION', `${this.id} picked up cargo at ${this.currentTargetStation.name}.`);
              this.assignNextTask();
            } else if (this.currentTargetStation.type === 'dropoff') {
              this.carryingPayload = false;
              this.deliveriesCompleted++;
              updateTotalDeliveries();
              playCompleteBeep();
              addTelemetry('MISSION', `${this.id} completed delivery at ${this.currentTargetStation.name}! (Total: ${this.deliveriesCompleted})`);
              this.assignNextTask();
            } else {
              this.assignNextTask();
            }
          }

          setManualDestination(col, row, x, y, name = 'Target Waypoint') {
            this.currentTargetStation = {
              name: name,
              col: col,
              row: row,
              x: x,
              y: y,
              type: 'manual',
              isManualWaypoint: true
            };
            this.state = 'NAVIGATING';
            this.statusReason = `Dispatched to (${Math.round(x)}, ${Math.round(y)})`;
            this.replan();
            addTelemetry('MISSION', `${this.id} manually dispatched to target (${Math.round(x)}, ${Math.round(y)}).`);
          }

          teleport(x, y) {
            this.x = x;
            this.y = y;
            this.speed = 0;
            this.replan();
            addTelemetry('P2P', `Operator teleported ${this.id} to (${Math.round(x)}, ${Math.round(y)}).`);
          }

          teleop(action) {
            if (action === 'fwd') {
              this.speed = Math.min(this.maxSpeed, this.speed + 15);
              this.x += Math.cos(this.heading) * 12;
              this.y += Math.sin(this.heading) * 12;
              this.statusReason = 'Manual Teleop Driving Forward';
            } else if (action === 'back') {
              this.x -= Math.cos(this.heading) * 10;
              this.y -= Math.sin(this.heading) * 10;
              this.statusReason = 'Manual Teleop Reversing';
            } else if (action === 'left') {
              this.heading -= 0.25;
              this.statusReason = 'Manual Teleop Steering Left';
            } else if (action === 'right') {
              this.heading += 0.25;
              this.statusReason = 'Manual Teleop Steering Right';
            } else if (action === 'stop') {
              this.speed = 0;
              this.state = 'BLOCKED';
              this.statusReason = 'Manual Teleop Emergency Stop';
              addTelemetry('P2P', `Emergency halt issued to ${this.id}`);
            }
            this.x = Math.max(15, Math.min(WORLD_W - 15, this.x));
            this.y = Math.max(15, Math.min(WORLD_H - 15, this.y));
            this.predictedHorizon = [];
          }
        }

        // --- FLEET INITIALIZATION ---
        const fleet = [
          new AMR({
            id: 'AMR-01',
            name: 'Alpha',
            color: '#06b6d4',
            accent: 'rgba(6, 182, 212, 0.25)',
            initialX: 2 * CELL_SIZE + 12,
            initialY: 6 * CELL_SIZE + 12,
            initialHeading: 0,
            basePriority: 3,
            battery: 88,
            initialDestination: STATIONS.DROPOFF_1
          }),
          new AMR({
            id: 'AMR-02',
            name: 'Beta',
            color: '#f59e0b',
            accent: 'rgba(245, 158, 11, 0.25)',
            initialX: 45 * CELL_SIZE + 12,
            initialY: 14 * CELL_SIZE + 12,
            initialHeading: Math.PI,
            basePriority: 2,
            battery: 76,
            initialDestination: STATIONS.PICKUP_2
          }),
          new AMR({
            id: 'AMR-03',
            name: 'Gamma',
            color: '#10b981',
            accent: 'rgba(16, 185, 129, 0.25)',
            initialX: 24 * CELL_SIZE + 12,
            initialY: 29 * CELL_SIZE + 12,
            initialHeading: -Math.PI / 2,
            basePriority: 2,
            battery: 92,
            initialDestination: STATIONS.PICKUP_3
          }),
          new AMR({
            id: 'AMR-04',
            name: 'Delta',
            color: '#a855f7',
            accent: 'rgba(168, 85, 247, 0.25)',
            initialX: 24 * CELL_SIZE + 12,
            initialY: 2 * CELL_SIZE + 12,
            initialHeading: Math.PI / 2,
            basePriority: 4,
            battery: 64,
            initialDestination: STATIONS.DROPOFF_3
          })
        ];

        let selectedAMR = fleet[0];

        // --- TELEMETRY & STATS SYSTEM ---
        let simTime = 0;
        let isRunning = true;
        let simSpeed = 2.0;
        let totalDeliveries = 0;
        let totalDeconflictions = 0;
        let totalCollisions = 0;
        let packetsPerSec = 0;
        let packetsCountInWindow = 0;

        const telemetryLogs = [];
        const maxLogs = 120;

        function addTelemetry(tag, message) {
          const timestamp = formatSimTime(simTime);
          const entry = { time: timestamp, tag, message };
          telemetryLogs.unshift(entry);
          if (telemetryLogs.length > maxLogs) telemetryLogs.pop();
          renderTelemetryLog();
        }

        function formatSimTime(sec) {
          const m = Math.floor(sec / 60);
          const s = (sec % 60).toFixed(1);
          return `${m.toString().padStart(2, '0')}:${s.padStart(4, '0')}`;
        }

        function updateTotalDeliveries() {
          totalDeliveries++;
          document.getElementById('hdr-deliveries').textContent = totalDeliveries;
          recordDeliveryEvent(simTime);
        }

        // --- D3 REAL-TIME FLEET THROUGHPUT (DPM) ENGINE ---
        const deliveryTimestamps = [];
        const throughputSamples = [];
        let peakDpm = 0;

        // Initialize with 60 historical second slots (trailing 60 seconds)
        for (let i = 59; i >= 0; i--) {
          throughputSamples.push({ timeAgo: -i, dpm: 0 });
        }

        function recordDeliveryEvent(t) {
          deliveryTimestamps.push(t);
        }

        function updateThroughputMetrics() {
          const windowSec = 60;
          const cutoff = simTime - windowSec;

          // Prune events outside rolling 60-second window
          while (deliveryTimestamps.length > 0 && deliveryTimestamps[0] < cutoff) {
            deliveryTimestamps.shift();
          }

          // Count deliveries in the last 60 seconds
          const recentCount = deliveryTimestamps.length;
          // Calculate Deliveries Per Minute (DPM)
          const effectiveTimeWindow = Math.min(windowSec, Math.max(10, simTime));
          const currentDpm = Number(((recentCount / effectiveTimeWindow) * 60).toFixed(1));

          if (currentDpm > peakDpm) {
            peakDpm = currentDpm;
          }

          // Push new sample
          throughputSamples.push({ timeAgo: 0, dpm: currentDpm });
          if (throughputSamples.length > 60) {
            throughputSamples.shift();
          }

          // Shift timeAgo indices (-59 ... 0)
          for (let i = 0; i < throughputSamples.length; i++) {
            throughputSamples[i].timeAgo = -(throughputSamples.length - 1 - i);
          }

          // Average DPM over the trailing window
          const sumDpm = throughputSamples.reduce((acc, s) => acc + s.dpm, 0);
          const avgDpm = (sumDpm / throughputSamples.length).toFixed(1);

          // Update HUD readout elements
          const curEl = document.getElementById('d3-stat-current');
          const peakEl = document.getElementById('d3-stat-peak');
          const avgEl = document.getElementById('d3-stat-avg');
          if (curEl) curEl.textContent = currentDpm.toFixed(1);
          if (peakEl) peakEl.textContent = peakDpm.toFixed(1);
          if (avgEl) avgEl.textContent = avgDpm;

          renderD3ThroughputChart();
        }

        function renderD3ThroughputChart() {
          const container = document.getElementById('d3-chart-wrapper');
          const svgEl = document.getElementById('d3-throughput-svg');
          if (!container || !svgEl) return;

          const rect = container.getBoundingClientRect();
          if (rect.width <= 0) return; // pane not currently visible

          const width = rect.width;
          const height = rect.height || 160;
          const margin = { top: 12, right: 16, bottom: 22, left: 28 };
          const innerW = width - margin.left - margin.right;
          const innerH = height - margin.top - margin.bottom;

          if (window.d3) {
            const d3 = window.d3;
            const svg = d3.select(svgEl);
            svg.attr('viewBox', `0 0 ${width} ${height}`);
            svg.selectAll('*').remove();

            // Gradient for glowing area
            const defs = svg.append('defs');
            const grad = defs.append('linearGradient')
              .attr('id', 'd3-throughput-gradient')
              .attr('x1', '0%').attr('y1', '0%')
              .attr('x2', '0%').attr('y2', '100%');
            grad.append('stop').attr('offset', '0%').attr('stop-color', '#06b6d4').attr('stop-opacity', 0.4);
            grad.append('stop').attr('offset', '100%').attr('stop-color', '#06b6d4').attr('stop-opacity', 0.0);

            const g = svg.append('g').attr('transform', `translate(${margin.left},${margin.top})`);

            // Scales
            const xScale = d3.scaleLinear()
              .domain([-60, 0])
              .range([0, innerW]);

            const maxDataDpm = d3.max(throughputSamples, d => d.dpm) || 0;
            const yDomainMax = Math.max(6, Math.ceil(maxDataDpm * 1.3));
            const yScale = d3.scaleLinear()
              .domain([0, yDomainMax])
              .range([innerH, 0]);

            // Subtle Gridlines
            const yGrid = d3.axisLeft(yScale)
              .ticks(4)
              .tickSize(-innerW)
              .tickFormat('');
            g.append('g')
              .attr('class', 'd3-grid')
              .call(yGrid);

            // Area under curve
            const area = d3.area()
              .x(d => xScale(d.timeAgo))
              .y0(innerH)
              .y1(d => yScale(d.dpm))
              .curve(d3.curveMonotoneX);

            g.append('path')
              .datum(throughputSamples)
              .attr('class', 'd3-area')
              .attr('d', area);

            // Line stroke
            const line = d3.line()
              .x(d => xScale(d.timeAgo))
              .y(d => yScale(d.dpm))
              .curve(d3.curveMonotoneX);

            g.append('path')
              .datum(throughputSamples)
              .attr('class', 'd3-line')
              .attr('d', line);

            // Axes
            const xAxis = d3.axisBottom(xScale)
              .ticks(5)
              .tickFormat(d => d === 0 ? 'Now' : `${d}s`);
            g.append('g')
              .attr('class', 'd3-axis')
              .attr('transform', `translate(0,${innerH})`)
              .call(xAxis);

            const yAxis = d3.axisLeft(yScale)
              .ticks(4)
              .tickFormat(d => `${d}`);
            g.append('g')
              .attr('class', 'd3-axis')
              .call(yAxis);

            // Pulse point at current now position
            const latest = throughputSamples[throughputSamples.length - 1];
            if (latest) {
              const cx = xScale(latest.timeAgo);
              const cy = yScale(latest.dpm);

              g.append('circle')
                .attr('cx', cx)
                .attr('cy', cy)
                .attr('r', 7)
                .attr('fill', 'rgba(6, 182, 212, 0.35)');

              g.append('circle')
                .attr('cx', cx)
                .attr('cy', cy)
                .attr('r', 3.5)
                .attr('class', 'd3-point');
            }

            // Interactive Tooltip on hover
            const tooltip = document.getElementById('d3-chart-tooltip');
            const bisect = d3.bisector(d => d.timeAgo).center;

            svg.on('mousemove', function (event) {
              if (!tooltip) return;
              const [mx, my] = d3.pointer(event, g.node());
              if (mx < 0 || mx > innerW || my < 0 || my > innerH) {
                tooltip.style.display = 'none';
                return;
              }
              const x0 = xScale.invert(mx);
              const idx = bisect(throughputSamples, x0);
              const d = throughputSamples[idx];
              if (d) {
                tooltip.style.display = 'block';
                tooltip.style.left = `${margin.left + xScale(d.timeAgo)}px`;
                tooltip.style.top = `${margin.top + yScale(d.dpm)}px`;
                tooltip.innerHTML = `<strong>${d.timeAgo === 0 ? 'Now' : d.timeAgo + 's'}</strong>: ${d.dpm.toFixed(1)} DPM`;
              }
            });

            svg.on('mouseleave', function () {
              if (tooltip) tooltip.style.display = 'none';
            });
          } else {
            // Offline Zero-Setup Fallback Renderer
            renderFallbackSVG(svgEl, innerW, innerH, margin, width, height);
          }
        }

        function renderFallbackSVG(svgEl, innerW, innerH, margin, width, height) {
          svgEl.setAttribute('viewBox', `0 0 ${width} ${height}`);
          svgEl.innerHTML = '';

          const maxDataDpm = throughputSamples.reduce((max, d) => Math.max(max, d.dpm), 0);
          const yDomainMax = Math.max(6, Math.ceil(maxDataDpm * 1.3));

          const getX = t => margin.left + ((t + 60) / 60) * innerW;
          const getY = v => margin.top + innerH - (v / yDomainMax) * innerH;

          let pathD = '';
          let areaD = `M ${getX(-60)} ${margin.top + innerH} `;

          throughputSamples.forEach((pt, i) => {
            const x = getX(pt.timeAgo);
            const y = getY(pt.dpm);
            if (i === 0) {
              pathD += `M ${x} ${y}`;
              areaD += `L ${x} ${y}`;
            } else {
              pathD += ` L ${x} ${y}`;
              areaD += ` L ${x} ${y}`;
            }
          });
          areaD += ` L ${getX(0)} ${margin.top + innerH} Z`;

          const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
          defs.innerHTML = `
            <linearGradient id="d3-throughput-gradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stop-color="#06b6d4" stop-opacity="0.4"/>
              <stop offset="100%" stop-color="#06b6d4" stop-opacity="0.0"/>
            </linearGradient>
          `;
          svgEl.appendChild(defs);

          // Grid lines
          for (let tick = 0; tick <= 4; tick++) {
            const yVal = (tick / 4) * yDomainMax;
            const yPos = getY(yVal);
            const gridLine = document.createElementNS('http://www.w3.org/2000/svg', 'line');
            gridLine.setAttribute('x1', margin.left);
            gridLine.setAttribute('y1', yPos);
            gridLine.setAttribute('x2', margin.left + innerW);
            gridLine.setAttribute('y2', yPos);
            gridLine.setAttribute('stroke', 'rgba(255,255,255,0.05)');
            svgEl.appendChild(gridLine);

            const yText = document.createElementNS('http://www.w3.org/2000/svg', 'text');
            yText.setAttribute('x', margin.left - 6);
            yText.setAttribute('y', yPos + 3);
            yText.setAttribute('text-anchor', 'end');
            yText.setAttribute('fill', '#64748b');
            yText.setAttribute('font-size', '9px');
            yText.setAttribute('font-family', 'ui-monospace, monospace');
            yText.textContent = Math.round(yVal);
            svgEl.appendChild(yText);
          }

          // X Axis ticks
          [-60, -45, -30, -15, 0].forEach(t => {
            const xPos = getX(t);
            const xText = document.createElementNS('http://www.w3.org/2000/svg', 'text');
            xText.setAttribute('x', xPos);
            xText.setAttribute('y', margin.top + innerH + 16);
            xText.setAttribute('text-anchor', 'middle');
            xText.setAttribute('fill', '#64748b');
            xText.setAttribute('font-size', '9px');
            xText.setAttribute('font-family', 'ui-monospace, monospace');
            xText.textContent = t === 0 ? 'Now' : `${t}s`;
            svgEl.appendChild(xText);
          });

          // Area
          const areaPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
          areaPath.setAttribute('d', areaD);
          areaPath.setAttribute('fill', 'url(#d3-throughput-gradient)');
          svgEl.appendChild(areaPath);

          // Line
          const linePath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
          linePath.setAttribute('d', pathD);
          linePath.setAttribute('fill', 'none');
          linePath.setAttribute('stroke', '#06b6d4');
          linePath.setAttribute('stroke-width', '2.2');
          svgEl.appendChild(linePath);

          // Pulse point
          const latest = throughputSamples[throughputSamples.length - 1];
          if (latest) {
            const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            circle.setAttribute('cx', getX(0));
            circle.setAttribute('cy', getY(latest.dpm));
            circle.setAttribute('r', '3.5');
            circle.setAttribute('fill', '#06b6d4');
            circle.setAttribute('stroke', '#fff');
            circle.setAttribute('stroke-width', '1.5');
            svgEl.appendChild(circle);
          }
        }

        // --- RENDERING PIPELINE (HTML5 Canvas API) ---
        const canvas = document.getElementById('sim-canvas');
        const ctx = canvas.getContext('2d');
        let baseScale = 1;
        let zoomLevel = 1.0;
        let viewScale = 1;
        let viewOffsetX = 0;
        let viewOffsetY = 0;
        let panOffsetX = 0;
        let panOffsetY = 0;

        function updateZoomUI() {
          const pct = Math.round(zoomLevel * 100);
          const navLabel = document.getElementById('nav-zoom-label');
          if (navLabel) navLabel.textContent = `Zoom: ${pct}%`;
          const vpIndicator = document.getElementById('viewport-zoom-indicator');
          if (vpIndicator) vpIndicator.textContent = `${pct}%`;

          // Update active check in dropdown
          document.querySelectorAll('[data-zoom]').forEach(btn => {
            const z = parseFloat(btn.dataset.zoom);
            const isMatch = Math.abs(z - zoomLevel) < 0.05;
            btn.classList.toggle('active', isMatch);
          });
        }

        function setZoom(newZoom, centerX = null, centerY = null) {
          const clamped = Math.min(Math.max(newZoom, 0.4), 3.5);
          const rect = canvas.parentElement.getBoundingClientRect();
          const cx = centerX !== null ? centerX : rect.width / 2;
          const cy = centerY !== null ? centerY : rect.height / 2;

          // Maintain mouse or screen center anchor point
          const oldScale = baseScale * zoomLevel;
          const newScale = baseScale * clamped;

          const worldX = (cx - (viewOffsetX + panOffsetX)) / oldScale;
          const worldY = (cy - (viewOffsetY + panOffsetY)) / oldScale;

          zoomLevel = clamped;
          viewScale = newScale;

          panOffsetX = cx - viewOffsetX - worldX * newScale;
          panOffsetY = cy - viewOffsetY - worldY * newScale;

          updateZoomUI();
        }

        function resetZoom() {
          zoomLevel = 1.0;
          panOffsetX = 0;
          panOffsetY = 0;
          viewScale = baseScale * zoomLevel;
          updateZoomUI();
          addTelemetry('P2P', 'Viewport zoom reset to default warehouse fit (100%).');
        }

        function resizeCanvas() {
          const rect = canvas.parentElement.getBoundingClientRect();
          const dpr = window.devicePixelRatio || 1;
          canvas.width = rect.width * dpr;
          canvas.height = rect.height * dpr;
          canvas.style.width = rect.width + 'px';
          canvas.style.height = rect.height + 'px';

          // Fit world to cover the screen entirely
          const scaleX = rect.width / WORLD_W;
          const scaleY = rect.height / WORLD_H;
          baseScale = Math.max(scaleX, scaleY);
          viewScale = baseScale * zoomLevel;
          viewOffsetX = (rect.width - WORLD_W * viewScale) / 2;
          viewOffsetY = (rect.height - WORLD_H * viewScale) / 2;
          updateZoomUI();
        }

        window.addEventListener('resize', () => {
          resizeCanvas();
          renderD3ThroughputChart();
        });
        resizeCanvas();

        // Layer visibility toggles
        let showP2PMesh = true;
        let showTrajectories = true;
        let showHalos = true;
        let showAllNav = false; // Clean Focused View by default to prevent visual clutter; toggle to show all simultaneously

        function drawWarehouseFloor() {
          // Floor base
          ctx.fillStyle = '#0a0e1a';
          ctx.fillRect(0, 0, WORLD_W, WORLD_H);

          // Subtle floor grid
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.025)';
          ctx.lineWidth = 1;
          for (let x = 0; x <= WORLD_W; x += CELL_SIZE) {
            ctx.beginPath();
            ctx.moveTo(x, 0);
            ctx.lineTo(x, WORLD_H);
            ctx.stroke();
          }
          for (let y = 0; y <= WORLD_H; y += CELL_SIZE) {
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(WORLD_W, y);
            ctx.stroke();
          }

          // Main transit corridors with dashed lane markers
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.06)';
          ctx.setLineDash([8, 8]);
          // Central crossway
          ctx.beginPath();
          ctx.moveTo(24 * CELL_SIZE + CELL_SIZE / 2, 2 * CELL_SIZE);
          ctx.lineTo(24 * CELL_SIZE + CELL_SIZE / 2, 29 * CELL_SIZE);
          ctx.stroke();
          // Horizontal highway
          ctx.beginPath();
          ctx.moveTo(3 * CELL_SIZE, 14 * CELL_SIZE + CELL_SIZE / 2);
          ctx.lineTo(44 * CELL_SIZE, 14 * CELL_SIZE + CELL_SIZE / 2);
          ctx.stroke();
          ctx.setLineDash([]);

          // Central intersection hazard box
          drawHazardZone(23 * CELL_SIZE, 13 * CELL_SIZE, 3 * CELL_SIZE, 3 * CELL_SIZE, 'CHOKE POINT: MAIN JUNCTION');

          // Draw Shelving Racks
          racks.forEach(rack => {
            const rx = rack.c1 * CELL_SIZE;
            const ry = rack.r1 * CELL_SIZE;
            const rw = (rack.c2 - rack.c1 + 1) * CELL_SIZE;
            const rh = (rack.r2 - rack.r1 + 1) * CELL_SIZE;

            // Shadow
            ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
            ctx.fillRect(rx + 2, ry + 2, rw, rh);

            // Rack body
            ctx.fillStyle = '#1e2638';
            ctx.fillRect(rx, ry, rw, rh);
            ctx.strokeStyle = '#334155';
            ctx.lineWidth = 1.5;
            ctx.strokeRect(rx, ry, rw, rh);

            // Shelf bays & pallet graphics
            const bayW = CELL_SIZE;
            const bayH = CELL_SIZE;
            for (let bx = rx; bx < rx + rw - 2; bx += bayW) {
              for (let by = ry; by < ry + rh - 2; by += bayH) {
                // Shelf uprights
                ctx.fillStyle = '#0f172a';
                ctx.fillRect(bx + 2, by + 2, bayW - 4, bayH - 4);
                // Pallet cargo box
                ctx.fillStyle = '#3b4252';
                ctx.fillRect(bx + 4, by + 4, bayW - 8, bayH - 8);
              }
            }

            // Rack Label
            ctx.fillStyle = '#64748b';
            ctx.font = 'bold 9px ' + 'var(--font-mono)';
            ctx.fillText(rack.label, rx + 4, ry - 4);
          });

          // Draw Stations
          drawStation(STATIONS.PICKUP_1, '#10b981', 'INBOUND 1');
          drawStation(STATIONS.PICKUP_2, '#10b981', 'INBOUND 2');
          drawStation(STATIONS.PICKUP_3, '#10b981', 'INBOUND 3');

          drawStation(STATIONS.DROPOFF_1, '#a855f7', 'PACK DOCK 1');
          drawStation(STATIONS.DROPOFF_2, '#a855f7', 'PACK DOCK 2');
          drawStation(STATIONS.DROPOFF_3, '#a855f7', 'PACK DOCK 3');

          drawChargingBay(STATIONS.CHARGE_1, 'DOCK 1');
          drawChargingBay(STATIONS.CHARGE_2, 'DOCK 2');

          // Draw Custom Stations
          Object.keys(STATIONS).forEach(key => {
            const st = STATIONS[key];
            if (st && st.custom) {
              const col = st.type === 'pickup' ? '#10b981' : st.type === 'dropoff' ? '#a855f7' : st.type === 'charge' ? '#06b6d4' : '#38bdf8';
              drawStation(st, col, (st.name || 'CUSTOM DOCK').toUpperCase());
            }
          });

          // Draw Dynamic Obstacles
          dynamicObstacles.forEach(idx => {
            const c = idx % GRID_COLS;
            const r = Math.floor(idx / GRID_COLS);
            const ox = c * CELL_SIZE;
            const oy = r * CELL_SIZE;

            // Hazard striped box
            ctx.save();
            ctx.fillStyle = 'rgba(239, 68, 68, 0.2)';
            ctx.fillRect(ox, oy, CELL_SIZE, CELL_SIZE);
            ctx.strokeStyle = '#ef4444';
            ctx.lineWidth = 2;
            ctx.strokeRect(ox + 1, oy + 1, CELL_SIZE - 2, CELL_SIZE - 2);

            // Caution Cross
            ctx.beginPath();
            ctx.moveTo(ox + 3, oy + 3);
            ctx.lineTo(ox + CELL_SIZE - 3, oy + CELL_SIZE - 3);
            ctx.moveTo(ox + CELL_SIZE - 3, oy + 3);
            ctx.lineTo(ox + 3, oy + CELL_SIZE - 3);
            ctx.stroke();

            // Label
            ctx.fillStyle = '#f87171';
            ctx.font = 'bold 8px ' + 'var(--font-mono)';
            ctx.fillText('SPILL', ox + 2, oy + CELL_SIZE / 2 + 3);
            ctx.restore();
          });
        }

        function drawHazardZone(x, y, w, h, label) {
          ctx.fillStyle = 'rgba(245, 158, 11, 0.05)';
          ctx.fillRect(x, y, w, h);
          ctx.strokeStyle = 'rgba(245, 158, 11, 0.3)';
          ctx.lineWidth = 1;
          ctx.setLineDash([4, 4]);
          ctx.strokeRect(x, y, w, h);
          ctx.setLineDash([]);

          ctx.fillStyle = 'rgba(245, 158, 11, 0.4)';
          ctx.font = 'bold 8px ' + 'var(--font-mono)';
          ctx.fillText(label, x + 4, y + 10);
        }

        function drawStation(st, color, title) {
          const sw = CELL_SIZE * 1.5;
          const sh = CELL_SIZE * 2;
          const sx = st.x - sw / 2;
          const sy = st.y - sh / 2;

          ctx.fillStyle = 'rgba(255, 255, 255, 0.03)';
          ctx.fillRect(sx, sy, sw, sh);
          ctx.strokeStyle = color;
          ctx.lineWidth = 1.5;
          ctx.strokeRect(sx, sy, sw, sh);

          // Rollers texture
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
          ctx.lineWidth = 1;
          for (let ry = sy + 6; ry < sy + sh - 4; ry += 6) {
            ctx.beginPath();
            ctx.moveTo(sx + 3, ry);
            ctx.lineTo(sx + sw - 3, ry);
            ctx.stroke();
          }

          ctx.fillStyle = color;
          ctx.font = 'bold 8px ' + 'var(--font-mono)';
          ctx.fillText(title, sx, sy - 4);
        }

        function drawChargingBay(st, title) {
          const sw = CELL_SIZE * 2;
          const sh = CELL_SIZE * 1.4;
          const sx = st.x - sw / 2;
          const sy = st.y - sh / 2;

          ctx.fillStyle = 'rgba(6, 182, 212, 0.08)';
          ctx.fillRect(sx, sy, sw, sh);
          ctx.strokeStyle = '#06b6d4';
          ctx.lineWidth = 1.5;
          ctx.strokeRect(sx, sy, sw, sh);

          // Induction coil symbol
          ctx.strokeStyle = 'rgba(6, 182, 212, 0.5)';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.arc(st.x, st.y, 8, 0, Math.PI * 2);
          ctx.stroke();

          ctx.fillStyle = '#06b6d4';
          ctx.font = 'bold 8px ' + 'var(--font-mono)';
          ctx.fillText(title, sx + 4, sy - 4);
        }

        // Draw P2P Network Mesh Lines & Radio Pulses
        function drawP2PMesh() {
          if (!showP2PMesh) return;

          for (let i = 0; i < fleet.length; i++) {
            for (let j = i + 1; j < fleet.length; j++) {
              const a = fleet[i];
              const b = fleet[j];

              // In clean view (!showAllNav), only draw mesh links connected to the selected AMR (or between yielding/conflict robots)
              if (!showAllNav && selectedAMR) {
                const isConflict = a.state === 'YIELDING' || b.state === 'YIELDING';
                if (a !== selectedAMR && b !== selectedAMR && !isConflict) continue;
              }

              const dist = Math.hypot(b.x - a.x, b.y - a.y);

              if (dist <= COMMS_RADIUS) {
                packetsCountInWindow++;
                const opacity = (1 - dist / COMMS_RADIUS) * 0.5;

                // Mesh broadcast line
                ctx.strokeStyle = `rgba(6, 182, 212, ${opacity})`;
                ctx.lineWidth = 1.2;
                ctx.setLineDash([4, 4]);
                ctx.beginPath();
                ctx.moveTo(a.x, a.y);
                ctx.lineTo(b.x, b.y);
                ctx.stroke();
                ctx.setLineDash([]);

                // Traveling radio packet animation
                const packetPhase = (simTime * 2.5) % 1.0;
                const px = a.x + (b.x - a.x) * packetPhase;
                const py = a.y + (b.y - a.y) * packetPhase;
                ctx.fillStyle = '#38bdf8';
                ctx.beginPath();
                ctx.arc(px, py, 2.5, 0, Math.PI * 2);
                ctx.fill();
              }
            }
          }
        }

        // Draw AMR Robot, Trajectories, and Halos
        function drawAMRs() {
          fleet.forEach(amr => {
            const isSel = amr === selectedAMR;
            // Clean view mode: only render full navigation graphics (trajectories, LIDAR cones, halos, waypoints)
            // for the selected AMR or during active yielding/conflict, eliminating visual clutter
            const showThisAmrNav = showAllNav || isSel || (!selectedAMR && amr === fleet[0]);

            // 1. P2P Radio Broadcast Halo
            if (showHalos && (showAllNav || isSel)) {
              ctx.strokeStyle = isSel ? 'rgba(6, 182, 212, 0.35)' : 'rgba(255, 255, 255, 0.04)';
              ctx.lineWidth = 1;
              ctx.setLineDash([6, 6]);
              ctx.beginPath();
              ctx.arc(amr.x, amr.y, COMMS_RADIUS, 0, Math.PI * 2);
              ctx.stroke();
              ctx.setLineDash([]);
            }

            // 2. Safety Clearance Halo
            if (showHalos && (showThisAmrNav || amr.state === 'YIELDING')) {
              ctx.strokeStyle = amr.state === 'YIELDING' ? 'rgba(245, 158, 11, 0.7)' : amr.color + '44';
              ctx.fillStyle = amr.state === 'YIELDING' ? 'rgba(245, 158, 11, 0.1)' : amr.color + '11';
              ctx.lineWidth = 1.5;
              ctx.beginPath();
              ctx.arc(amr.x, amr.y, SAFETY_RADIUS, 0, Math.PI * 2);
              ctx.fill();
              ctx.stroke();
            }

            // 3. Sensor Cone (LIDAR sweep forward)
            if (showHalos && showThisAmrNav) {
              ctx.save();
              ctx.translate(amr.x, amr.y);
              ctx.rotate(amr.heading);
              ctx.fillStyle = amr.color + '18';
              ctx.beginPath();
              ctx.moveTo(0, 0);
              ctx.arc(0, 0, 52, -Math.PI / 4, Math.PI / 4);
              ctx.closePath();
              ctx.fill();
              ctx.restore();
            }

            // 4. Planned Path and Projected Space-Time Trajectory Horizon
            if (showTrajectories && showThisAmrNav) {
              // Full planned corridor path line
              if (amr.path && amr.path.length > 0 && amr.pathIndex < amr.path.length) {
                ctx.save();
                ctx.strokeStyle = amr.color + '44';
                ctx.lineWidth = isSel ? 1.8 : 1.2;
                ctx.setLineDash([3, 3]);
                ctx.beginPath();
                ctx.moveTo(amr.x, amr.y);
                for (let i = amr.pathIndex; i < amr.path.length; i++) {
                  ctx.lineTo(amr.path[i].x, amr.path[i].y);
                }
                ctx.stroke();
                ctx.restore();
              }

              // Dynamic projected space-time horizon vector
              if (amr.predictedHorizon && amr.predictedHorizon.length > 1) {
                ctx.strokeStyle = amr.state === 'YIELDING' ? 'rgba(245, 158, 11, 0.9)' : amr.color;
                ctx.lineWidth = isSel ? 2.5 : 1.6;
                ctx.beginPath();
                ctx.moveTo(amr.x, amr.y);
                for (let i = 1; i < amr.predictedHorizon.length; i++) {
                  ctx.lineTo(amr.predictedHorizon[i].x, amr.predictedHorizon[i].y);
                }
                ctx.stroke();

                // Trajectory Space-Time Beads
                amr.predictedHorizon.forEach((wp, idx) => {
                  if (idx % 2 === 0 && idx > 0) {
                    ctx.fillStyle = amr.color;
                    ctx.beginPath();
                    ctx.arc(wp.x, wp.y, 2.5, 0, Math.PI * 2);
                    ctx.fill();
                  }
                });
              }
            }

            // 5. Space-Time Conflict Alert Marker
            if (amr.spaceTimeConflictPoint && (showThisAmrNav || isSel || amr.state === 'YIELDING')) {
              const cp = amr.spaceTimeConflictPoint;
              const pulse = (Math.sin(simTime * 8) + 1) / 2;
              ctx.save();
              ctx.strokeStyle = '#ef4444';
              ctx.lineWidth = 2;
              ctx.beginPath();
              ctx.arc(cp.x, cp.y, 14 + pulse * 6, 0, Math.PI * 2);
              ctx.stroke();

              ctx.fillStyle = '#f59e0b';
              ctx.beginPath();
              ctx.arc(cp.x, cp.y, 4, 0, Math.PI * 2);
              ctx.fill();

              // Warning Tag
              ctx.fillStyle = '#ef4444';
              ctx.font = 'bold 9px ' + 'var(--font-mono)';
              ctx.fillText(`CONFLICT t=${cp.time?.toFixed(1)}s`, cp.x + 8, cp.y - 8);
              ctx.restore();
            }

            // 6. AMR Physical Chassis
            ctx.save();
            ctx.translate(amr.x, amr.y);
            ctx.rotate(amr.heading);

            // Drop shadow
            ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
            ctx.beginPath();
            ctx.roundRect(-14, -12, 28, 24, 4);
            ctx.fill();

            // Tread Wheels
            ctx.fillStyle = '#0f172a';
            ctx.fillRect(-12, -15, 24, 4); // Left tread
            ctx.fillRect(-12, 11, 24, 4);  // Right tread

            // Main Industrial Chassis
            ctx.fillStyle = isSel ? '#ffffff' : '#1e293b';
            ctx.strokeStyle = amr.color;
            ctx.lineWidth = isSel ? 2.5 : 1.8;
            ctx.beginPath();
            ctx.roundRect(-14, -11, 28, 22, 5);
            ctx.fill();
            ctx.stroke();

            // Inner Accent Plate
            ctx.fillStyle = amr.color + '33';
            ctx.fillRect(-8, -7, 16, 14);

            // Payload Cargo Box (if carrying)
            if (amr.carryingPayload) {
              ctx.fillStyle = '#3b82f6';
              ctx.strokeStyle = '#93c5fd';
              ctx.lineWidth = 1;
              ctx.fillRect(-6, -5, 12, 10);
              ctx.strokeRect(-6, -5, 12, 10);
            }

            // Forward Direction Indicator Arrow
            ctx.fillStyle = amr.color;
            ctx.beginPath();
            ctx.moveTo(10, 0);
            ctx.lineTo(4, -5);
            ctx.lineTo(4, 5);
            ctx.closePath();
            ctx.fill();

            // Rotating LIDAR scanner turret on top
            ctx.fillStyle = '#0f172a';
            ctx.beginPath();
            ctx.arc(0, 0, 4, 0, Math.PI * 2);
            ctx.fill();

            // Status LED flasher
            const ledColor = amr.state === 'NAVIGATING' ? '#10b981' :
                             amr.state === 'YIELDING' ? '#f59e0b' :
                             amr.state === 'CHARGING' ? '#06b6d4' : '#ef4444';
            ctx.fillStyle = ledColor;
            ctx.beginPath();
            ctx.arc(-8, 0, 2, 0, Math.PI * 2);
            ctx.fill();

            ctx.restore();

            // 7. AMR Overhead Tag
            ctx.fillStyle = isSel ? '#ffffff' : '#cbd5e1';
            ctx.font = 'bold 10px ' + 'var(--font-mono)';
            ctx.fillText(amr.id, amr.x - 18, amr.y - 18);

            // Priority Badge above head
            ctx.fillStyle = amr.color;
            ctx.font = 'bold 9px ' + 'var(--font-mono)';
            ctx.fillText(`P${amr.priority}`, amr.x + 18, amr.y - 18);

            // 8. Target Destination Waypoint Pin
            if (amr.currentTargetStation) {
              const tx = amr.currentTargetStation.x;
              const ty = amr.currentTargetStation.y;
              if (amr.currentTargetStation.isManualWaypoint || isSel || showAllNav) {
                ctx.save();
                ctx.strokeStyle = amr.color;
                ctx.lineWidth = 1.5;
                ctx.setLineDash([3, 3]);
                ctx.beginPath();
                ctx.arc(tx, ty, 9 + Math.sin(simTime * 5) * 2.5, 0, Math.PI * 2);
                ctx.stroke();
                ctx.fillStyle = amr.color;
                ctx.beginPath();
                ctx.arc(tx, ty, 3.5, 0, Math.PI * 2);
                ctx.fill();
                ctx.setLineDash([]);
                ctx.font = 'bold 8.5px var(--font-mono)';
                ctx.fillText(`🎯 ${amr.id}`, tx + 10, ty + 3);
                ctx.restore();
              }
            }
          });
        }

        // --- HARD COLLISION AUDITOR ---
        function checkCollisions() {
          for (let i = 0; i < fleet.length; i++) {
            for (let j = i + 1; j < fleet.length; j++) {
              const a = fleet[i];
              const b = fleet[j];
              const d = Math.hypot(b.x - a.x, b.y - a.y);
              if (d < 18) {
                // Physical overlap breached!
                a.collisionsCount++;
                b.collisionsCount++;
                totalCollisions++;
                document.getElementById('hdr-collisions').textContent = totalCollisions;
                document.getElementById('hdr-collisions').style.color = '#ef4444';
                addTelemetry('COLLISION', `CRITICAL: Proximity breach between ${a.id} and ${b.id} at (${Math.round(a.x)}, ${Math.round(a.y)})!`);
              }
            }
          }
        }

        // --- MAIN SIMULATION LOOP ---
        let lastTime = performance.now();
        let secondTimer = 0;

        function mainLoop(now) {
          const rawDt = (now - lastTime) / 1000;
          lastTime = now;
          const dt = Math.min(0.1, rawDt) * (isRunning ? simSpeed : 0);

          if (isRunning) {
            simTime += dt;
            document.getElementById('hdr-sim-time').textContent = formatSimTime(simTime);

            // 1. P2P Neighborhood Horizon Exchange
            fleet.forEach(amr => {
              amr.evaluateP2PBroadcast(fleet);
            });

            // 2. Kinematics & Physics update
            fleet.forEach(amr => {
              amr.update(dt);
            });

            // 3. Collision safety check
            checkCollisions();

            // 4. Update packet telemetry rate every second
            secondTimer += rawDt;
            if (secondTimer >= 1.0) {
              packetsPerSec = Math.round(packetsCountInWindow / secondTimer);
              document.getElementById('hdr-packets').textContent = packetsPerSec;
              packetsCountInWindow = 0;
              secondTimer = 0;

              // Update total deconflictions counter
              const totalDeconf = fleet.reduce((acc, r) => acc + r.deconflictionsCount, 0);
              document.getElementById('hdr-deconflictions').textContent = totalDeconf;

              // Update D3 Throughput metrics & chart
              updateThroughputMetrics();
            }
          }

          // Render Pass
          ctx.save();
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          
          const dpr = window.devicePixelRatio || 1;
          ctx.scale(dpr, dpr);
          
          // Apply transformation to center warehouse world with zoom and pan
          ctx.translate(viewOffsetX + panOffsetX, viewOffsetY + panOffsetY);
          ctx.scale(viewScale, viewScale);

          drawWarehouseFloor();
          drawP2PMesh();
          drawAMRs();

          ctx.restore();

          // Update HUD fleet cards (throttled every few frames)
          updateFleetCardsUI();

          requestAnimationFrame(mainLoop);
        }

        requestAnimationFrame(mainLoop);

        // --- UI & DASHBOARD UPDATES ---
        function updateFleetCardsUI() {
          const container = document.getElementById('fleet-card-list');
          if (!container) return;

          // Build or update cards
          fleet.forEach((amr, idx) => {
            let card = document.getElementById(`card-${amr.id}`);
            if (!card) {
              card = document.createElement('div');
              card.id = `card-${amr.id}`;
              card.className = 'robot-card';
              card.onclick = () => selectAMR(amr);
              container.appendChild(card);
            }

            if (amr === selectedAMR) {
              card.classList.add('selected');
            } else {
              card.classList.remove('selected');
            }

            const statusClass = `status-${amr.state.toLowerCase()}`;
            const battPct = Math.round(amr.battery);
            const battColor = battPct > 40 ? '#10b981' : battPct > 20 ? '#f59e0b' : '#ef4444';

            card.innerHTML = `
              <div class="robot-card-top">
                <div class="robot-identity">
                  <span class="robot-id-tag" style="background:${amr.accent}; color:${amr.color};">${amr.id}</span>
                  <span class="robot-name">${amr.name}</span>
                </div>
                <span class="status-pill ${statusClass}">
                  ${amr.state}
                </span>
              </div>

              <div class="robot-meta-grid">
                <div class="meta-item">
                  <span class="meta-label">Priority</span>
                  <span class="meta-value" style="color:${amr.color};">P${amr.priority} (${amr.priorityReason.split(' ')[0]})</span>
                </div>
                <div class="meta-item">
                  <span class="meta-label">Speed</span>
                  <span class="meta-value">${(amr.speed / 20).toFixed(1)} m/s</span>
                </div>
                <div class="meta-item">
                  <span class="meta-label">Deconflicts</span>
                  <span class="meta-value" style="color:var(--accent-amber);">${amr.deconflictionsCount}</span>
                </div>
              </div>

              <div style="display:flex; flex-direction:column; gap:3px;">
                <div style="display:flex; justify-content:space-between; font-size:10px; font-family:var(--font-mono);">
                  <span style="color:var(--text-muted);">BATTERY</span>
                  <span style="color:${battColor}; font-weight:700;">${battPct}%</span>
                </div>
                <div class="battery-track">
                  <div class="battery-fill" style="width:${battPct}%; background:${battColor};"></div>
                </div>
              </div>

              <div class="robot-footer">
                <span style="font-size:10.5px; color:var(--text-secondary); text-overflow:ellipsis; overflow:hidden; white-space:nowrap; max-width:240px;">
                  ${amr.statusReason}
                </span>
                <div class="card-actions">
                  <button class="mini-btn btn-primary" onclick="event.stopPropagation(); window.openAmrEditor('${amr.id}');" title="Manual Edit AMR">✏️ Edit</button>
                  <button class="mini-btn" onclick="event.stopPropagation(); window.overridePriority('${amr.id}');" title="Elevate Priority">P+</button>
                  <button class="mini-btn" onclick="event.stopPropagation(); window.sendToCharge('${amr.id}');" title="Send to Charger">⚡</button>
                </div>
              </div>
            `;
          });
        }

        function selectAMR(amr) {
          selectedAMR = amr;
          addTelemetry('P2P', `Selected ${amr.id} for telemetry telemetry tracking.`);
        }

        window.overridePriority = function (id) {
          const amr = fleet.find(r => r.id === id);
          if (amr) {
            amr.priority = amr.priority >= 5 ? 2 : amr.priority + 1;
            amr.priorityReason = 'Manual Operator Override';
            addTelemetry('P2P', `Operator override: ${amr.id} priority set to P${amr.priority}`);
          }
        };

        window.sendToCharge = function (id) {
          const amr = fleet.find(r => r.id === id);
          if (amr) {
            const charger = Math.random() > 0.5 ? STATIONS.CHARGE_1 : STATIONS.CHARGE_2;
            amr.currentTargetStation = charger;
            amr.priority = 5;
            amr.priorityReason = 'Manual Charger Dispatch';
            amr.replan();
            addTelemetry('BATTERY', `${amr.id} dispatched manually to ${charger.name}`);
          }
        };

        // --- TELEMETRY LOG RENDERER ---
        let currentFilter = 'ALL';
        const logContainer = document.getElementById('telemetry-log');

        function renderTelemetryLog() {
          if (!logContainer) return;
          const filtered = telemetryLogs.filter(item => {
            if (currentFilter === 'ALL') return true;
            if (currentFilter === 'CONFLICT') return item.tag === 'DECONFLICT';
            if (currentFilter === 'DETOUR') return item.tag === 'DETOUR' || item.tag === 'OBSTACLE';
            if (currentFilter === 'P2P') return item.tag === 'P2P' || item.tag === 'MISSION';
            return true;
          });

          logContainer.innerHTML = filtered.map(log => {
            const tagClass = `log-tag-${log.tag.toLowerCase()}`;
            return `
              <div class="log-row">
                <span class="log-time">[${log.time}]</span>
                <span class="log-tag ${tagClass}">[${log.tag}]</span>
                <span class="log-msg">${escapeHtml(log.message)}</span>
              </div>
            `;
          }).join('');
        }

        function escapeHtml(str) {
          return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        }

        // --- INTERACTION & EVENT LISTENERS ---
        // Nav Dropdowns (Tools, View Layers, & Zoom)
        const btnNavTool = document.getElementById('btn-nav-tool');
        const menuNavTool = document.getElementById('menu-nav-tool');
        const btnNavView = document.getElementById('btn-nav-view');
        const menuNavView = document.getElementById('menu-nav-view');
        const btnNavZoom = document.getElementById('btn-nav-zoom');
        const menuNavZoom = document.getElementById('menu-nav-zoom');

        function closeAllNavDropdowns() {
          btnNavTool?.classList.remove('open');
          menuNavTool?.classList.remove('show');
          btnNavView?.classList.remove('open');
          menuNavView?.classList.remove('show');
          btnNavZoom?.classList.remove('open');
          menuNavZoom?.classList.remove('show');
        }

        btnNavTool?.addEventListener('click', (e) => {
          e.stopPropagation();
          const isOpen = menuNavTool?.classList.contains('show');
          closeAllNavDropdowns();
          if (!isOpen) {
            btnNavTool.classList.add('open');
            menuNavTool?.classList.add('show');
          }
        });

        btnNavView?.addEventListener('click', (e) => {
          e.stopPropagation();
          const isOpen = menuNavView?.classList.contains('show');
          closeAllNavDropdowns();
          if (!isOpen) {
            btnNavView.classList.add('open');
            menuNavView?.classList.add('show');
          }
        });

        btnNavZoom?.addEventListener('click', (e) => {
          e.stopPropagation();
          const isOpen = menuNavZoom?.classList.contains('show');
          closeAllNavDropdowns();
          if (!isOpen) {
            btnNavZoom.classList.add('open');
            menuNavZoom?.classList.add('show');
          }
        });

        // Zoom dropdown preset buttons
        document.querySelectorAll('[data-zoom]').forEach(btn => {
          btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const z = parseFloat(btn.dataset.zoom);
            setZoom(z);
            closeAllNavDropdowns();
            addTelemetry('P2P', `Viewport zoom preset activated: ${Math.round(z * 100)}%`);
          });
        });

        document.getElementById('btn-zoom-reset-dropdown')?.addEventListener('click', (e) => {
          e.stopPropagation();
          resetZoom();
          closeAllNavDropdowns();
        });

        // Floating Viewport Zoom Controls (+, -, ⟲)
        document.getElementById('btn-zoom-in')?.addEventListener('click', (e) => {
          e.stopPropagation();
          setZoom(zoomLevel + 0.25);
        });

        document.getElementById('btn-zoom-out')?.addEventListener('click', (e) => {
          e.stopPropagation();
          setZoom(zoomLevel - 0.25);
        });

        document.getElementById('btn-zoom-reset')?.addEventListener('click', (e) => {
          e.stopPropagation();
          resetZoom();
        });

        document.addEventListener('click', (e) => {
          if (!e.target.closest('.nav-dropdown-wrapper')) {
            closeAllNavDropdowns();
          }
        });

        // Tool Selector with Label and Icon Updates
        const toolButtons = document.querySelectorAll('[data-tool]');
        const currentToolIcon = document.getElementById('current-tool-icon');
        const currentToolName = document.getElementById('current-tool-name');

        const toolMeta = {
          select: { icon: '🖱️', label: 'Tool: Select' },
          pan: { icon: '✋', label: 'Tool: Pan Canvas' },
          target: { icon: '🎯', label: 'Tool: Destination' },
          draw: { icon: '🧱', label: 'Tool: Draw Spill' },
          erase: { icon: '🧽', label: 'Tool: Erase' },
          station: { icon: '📌', label: 'Tool: Add Station' },
          teleport: { icon: '⚡', label: 'Tool: Teleport' }
        };

        function setToolMode(mode) {
          activeTool = mode;
          toolButtons.forEach(btn => {
            const isMatch = btn.dataset.tool === mode;
            btn.classList.toggle('active', isMatch);
            const check = btn.querySelector('.item-check');
            if (check) check.style.display = isMatch ? 'inline' : 'none';
          });

          if (toolMeta[mode]) {
            if (currentToolIcon) currentToolIcon.textContent = toolMeta[mode].icon;
            if (currentToolName) currentToolName.textContent = toolMeta[mode].label;
          }
          canvas.style.cursor = mode === 'pan' ? 'grab' : 'crosshair';
          closeAllNavDropdowns();
        }

        toolButtons.forEach(btn => {
          btn.addEventListener('click', () => setToolMode(btn.dataset.tool));
        });

        // Helper to convert screen coordinates to warehouse world coordinates
        function getCanvasWorldCoords(e) {
          const rect = canvas.getBoundingClientRect();
          const clientX = e.clientX - rect.left;
          const clientY = e.clientY - rect.top;
          return {
            x: (clientX - (viewOffsetX + panOffsetX)) / viewScale,
            y: (clientY - (viewOffsetY + panOffsetY)) / viewScale
          };
        }

        function getRobotAtWorldPos(wx, wy) {
          for (let amr of fleet) {
            if (Math.hypot(amr.x - wx, amr.y - wy) < 22) {
              return amr;
            }
          }
          return null;
        }

        // Canvas interactive mouse & pan operations
        let isMiddlePanning = false;
        let panStartX = 0;
        let panStartY = 0;

        canvas.addEventListener('mousedown', (e) => {
          // Middle click (button 1) or Left click with Space or Alt key or Pan tool initiates viewport pan
          if (e.button === 1 || (e.button === 0 && (e.altKey || e.shiftKey || activeTool === 'pan'))) {
            e.preventDefault();
            isMiddlePanning = true;
            panStartX = e.clientX - panOffsetX;
            panStartY = e.clientY - panOffsetY;
            canvas.style.cursor = 'grab';
            return;
          }

          if (e.button !== 0) return; // Primary left click
          const pos = getCanvasWorldCoords(e);
        window.__AMR_SIM__ = window.__AMR_SIM__ || {};
        window.__AMR_SIM__.handleWorldClick = function(worldX, worldY) {
          if (worldX < 0 || worldX > WORLD_W || worldY < 0 || worldY > WORLD_H) return;
          
          isPointerDragging = true;
          const clickedRobot = getRobotAtWorldPos(worldX, worldY);
          
          // Use a local pos object to minimize diff changes below
          const pos = { x: worldX, y: worldY };

          if (activeTool === 'select') {
            if (clickedRobot) {
              selectAMR(clickedRobot);
              window.openAmrEditor(clickedRobot.id);
            } else {
              toggleObstacleAtWorldPos(pos.x, pos.y);
            }
          } else if (activeTool === 'target') {
            const targetRobot = selectedAMR || fleet[0];
            if (targetRobot) {
              const c = Math.floor(pos.x / CELL_SIZE);
              const r = Math.floor(pos.y / CELL_SIZE);
              targetRobot.setManualDestination(c, r, pos.x, pos.y, 'Target Waypoint');
              playCompleteBeep();
            } else {
              addTelemetry('P2P', 'Please select an AMR first before setting destination.');
            }
          } else if (activeTool === 'draw') {
            const c = Math.floor(pos.x / CELL_SIZE);
            const r = Math.floor(pos.y / CELL_SIZE);
            const idx = gridIndex(c, r);
            if (grid[idx] === 0) {
              grid[idx] = 2;
              dynamicObstacles.add(idx);
              fleet.forEach(amr => amr.replan());
            }
          } else if (activeTool === 'erase') {
            const c = Math.floor(pos.x / CELL_SIZE);
            const r = Math.floor(pos.y / CELL_SIZE);
            const idx = gridIndex(c, r);
            if (grid[idx] === 2) {
              grid[idx] = 0;
              dynamicObstacles.delete(idx);
              fleet.forEach(amr => amr.replan());
            }
          } else if (activeTool === 'station') {
            const c = Math.floor(pos.x / CELL_SIZE);
            const r = Math.floor(pos.y / CELL_SIZE);
            window.openAddStationModal(c, r);
          } else if (activeTool === 'teleport') {
            const targetRobot = selectedAMR || fleet[0];
            if (targetRobot) {
              targetRobot.teleport(pos.x, pos.y);
              playTone(720, 'sine', 0.15, 0.05);
            } else {
              addTelemetry('P2P', 'Please select an AMR first before teleporting.');
            }
          }
        };

        // Call the shared handler for the old 2D canvas clicks
        window.__AMR_SIM__.handleWorldClick(pos.x, pos.y);
        });

        canvas.addEventListener('mousemove', (e) => {
          if (isMiddlePanning) {
            panOffsetX = e.clientX - panStartX;
            panOffsetY = e.clientY - panStartY;
            return;
          }

          if (!isPointerDragging) return;
          const pos = getCanvasWorldCoords(e);
          if (pos.x < 0 || pos.x > WORLD_W || pos.y < 0 || pos.y > WORLD_H) return;
          const c = Math.floor(pos.x / CELL_SIZE);
          const r = Math.floor(pos.y / CELL_SIZE);
          const idx = gridIndex(c, r);

          if (activeTool === 'draw') {
            if (grid[idx] === 0) {
              grid[idx] = 2;
              dynamicObstacles.add(idx);
              fleet.forEach(amr => amr.replan());
            }
          } else if (activeTool === 'erase') {
            if (grid[idx] === 2) {
              grid[idx] = 0;
              dynamicObstacles.delete(idx);
              fleet.forEach(amr => amr.replan());
            }
          }
        });

        window.addEventListener('mouseup', () => {
          isPointerDragging = false;
          if (isMiddlePanning) {
            isMiddlePanning = false;
            canvas.style.cursor = activeTool === 'pan' ? 'grab' : 'crosshair';
          }
        });

        // Mouse Wheel Zoom
        canvas.addEventListener('wheel', (e) => {
          e.preventDefault();
          const rect = canvas.getBoundingClientRect();
          const mouseX = e.clientX - rect.left;
          const mouseY = e.clientY - rect.top;
          const zoomDelta = e.deltaY < 0 ? 0.12 : -0.12;
          setZoom(zoomLevel + zoomDelta, mouseX, mouseY);
        }, { passive: false });

        // Quick Right-Click Dispatch
        canvas.addEventListener('contextmenu', (e) => {
          e.preventDefault();
          const pos = getCanvasWorldCoords(e);
          if (pos.x < 0 || pos.x > WORLD_W || pos.y < 0 || pos.y > WORLD_H) return;
          const targetRobot = selectedAMR || fleet[0];
          if (targetRobot) {
            const c = Math.floor(pos.x / CELL_SIZE);
            const r = Math.floor(pos.y / CELL_SIZE);
            targetRobot.setManualDestination(c, r, pos.x, pos.y, 'Direct Waypoint');
            playTone(660, 'sine', 0.1, 0.04);
            addTelemetry('MISSION', `Quick Right-Click: ${targetRobot.id} dispatched to (${Math.round(pos.x)}, ${Math.round(pos.y)})`);
          }
        });

        // Controls
        const btnPlayPause = document.getElementById('btn-play-pause');
        const txtPlayPause = document.getElementById('txt-play-pause');
        const iconPlayPause = document.getElementById('icon-play-pause');

        function togglePlayPause() {
          isRunning = !isRunning;
          txtPlayPause.textContent = isRunning ? 'Pause' : 'Play';
          iconPlayPause.innerHTML = isRunning
            ? '<path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/>'
            : '<path d="M8 5v14l11-7z"/>';
          addTelemetry('P2P', isRunning ? 'Simulation resumed.' : 'Simulation paused.');
        }

        btnPlayPause.addEventListener('click', togglePlayPause);

        window.addEventListener('keydown', (e) => {
          if (e.code === 'Space' && e.target.tagName !== 'INPUT') {
            e.preventDefault();
            togglePlayPause();
          }
        });

        document.getElementById('btn-step').addEventListener('click', () => {
          if (!isRunning) {
            simTime += 0.1;
            fleet.forEach(amr => {
              amr.evaluateP2PBroadcast(fleet);
              amr.update(0.1);
            });
          }
        });

        document.getElementById('btn-reset').addEventListener('click', () => {
          simTime = 0;
          totalDeliveries = 0;
          totalDeconflictions = 0;
          totalCollisions = 0;
          document.getElementById('hdr-deliveries').textContent = '0';
          document.getElementById('hdr-deconflictions').textContent = '0';
          document.getElementById('hdr-collisions').textContent = '0';
          clearAllObstacles();
          deliveryTimestamps.length = 0;
          peakDpm = 0;
          for (let i = 0; i < throughputSamples.length; i++) {
            throughputSamples[i].dpm = 0;
          }
          updateThroughputMetrics();
          fleet.forEach(amr => {
            amr.speed = 0;
            amr.battery = 90;
            amr.deconflictionsCount = 0;
            amr.collisionsCount = 0;
            amr.state = 'NAVIGATING';
            amr.assignNextTask();
          });
          addTelemetry('P2P', 'Fleet simulation reset to initial layout.');
        });

        // Speed buttons
        const speedButtons = document.querySelectorAll('[data-speed]');
        speedButtons.forEach(btn => {
          btn.addEventListener('click', () => {
            speedButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            simSpeed = parseFloat(btn.dataset.speed);
            addTelemetry('P2P', `Simulation clock speed set to ${simSpeed}x`);
          });
        });

        // Toggle layer buttons
        const btnToggleAllNav = document.getElementById('toggle-show-all-nav');
        const chkShowAllNav = document.getElementById('chk-show-all-nav');
        btnToggleAllNav.addEventListener('click', function (e) {
          e.stopPropagation();
          showAllNav = !showAllNav;
          this.classList.toggle('active', showAllNav);
          if (chkShowAllNav) chkShowAllNav.style.display = showAllNav ? 'inline' : 'none';
          addTelemetry('P2P', showAllNav 
            ? 'Navigation View: Showing all fleet trajectory lines simultaneously.' 
            : 'Navigation View: Clean Focused mode active (showing selected robot nav only to eliminate clutter).');
        });

        const chkP2p = document.getElementById('chk-p2p');
        document.getElementById('toggle-p2p').addEventListener('click', function (e) {
          e.stopPropagation();
          showP2PMesh = !showP2PMesh;
          this.classList.toggle('active', showP2PMesh);
          if (chkP2p) chkP2p.style.display = showP2PMesh ? 'inline' : 'none';
        });

        const chkTraj = document.getElementById('chk-traj');
        document.getElementById('toggle-traj').addEventListener('click', function (e) {
          e.stopPropagation();
          showTrajectories = !showTrajectories;
          this.classList.toggle('active', showTrajectories);
          if (chkTraj) chkTraj.style.display = showTrajectories ? 'inline' : 'none';
        });

        const chkHalos = document.getElementById('chk-halos');
        document.getElementById('toggle-halos').addEventListener('click', function (e) {
          e.stopPropagation();
          showHalos = !showHalos;
          this.classList.toggle('active', showHalos);
          if (chkHalos) chkHalos.style.display = showHalos ? 'inline' : 'none';
        });

        // Clear Obstacles button
        document.getElementById('btn-clear-obstacles').addEventListener('click', clearAllObstacles);

        // Sound Toggle
        const btnSound = document.getElementById('btn-sound');
        const soundLabel = document.getElementById('sound-label');
        if (btnSound && soundLabel) {
          btnSound.addEventListener('click', () => {
            initAudio();
            soundEnabled = !soundEnabled;
            soundLabel.textContent = soundEnabled ? 'Audio: On' : 'Audio: Off';
            btnSound.classList.toggle('active', soundEnabled);
            if (soundEnabled) playConflictBeep();
          });
        }

        // Tab Navigation
        const tabBtns = document.querySelectorAll('.tab-btn');
        const tabPanes = document.querySelectorAll('.tab-pane');
        tabBtns.forEach(btn => {
          btn.addEventListener('click', () => {
            tabBtns.forEach(b => b.classList.remove('active'));
            tabPanes.forEach(p => (p.style.display = 'none'));
            btn.classList.add('active');
            const targetPane = document.getElementById(`pane-${btn.dataset.tab}`);
            if (targetPane) targetPane.style.display = 'flex';
            if (btn.dataset.tab === 'arch') {
              setTimeout(renderD3ThroughputChart, 40);
            }
          });
        });

        // Log Filter & Clear
        document.getElementById('log-filter').addEventListener('change', (e) => {
          currentFilter = e.target.value;
          renderTelemetryLog();
        });
        document.getElementById('btn-clear-log').addEventListener('click', () => {
          telemetryLogs.length = 0;
          renderTelemetryLog();
        });

        // --- TEST SCENARIO PRESETS ---
        // Scenario 1: Choke Point Standoff (Two robots head-on in central aisle)
        document.getElementById('scen-choke').addEventListener('click', () => {
          clearAllObstacles();
          // AMR-01 Alpha from left to right through middle aisle
          fleet[0].x = 13 * CELL_SIZE;
          fleet[0].y = 14 * CELL_SIZE + CELL_SIZE / 2;
          fleet[0].heading = 0;
          fleet[0].priority = 4;
          fleet[0].priorityReason = 'Rush Express (P4)';
          fleet[0].currentTargetStation = STATIONS.DROPOFF_2;
          fleet[0].replan();

          // AMR-02 Beta from right to left in same aisle
          fleet[1].x = 35 * CELL_SIZE;
          fleet[1].y = 14 * CELL_SIZE + CELL_SIZE / 2;
          fleet[1].heading = Math.PI;
          fleet[1].priority = 2;
          fleet[1].priorityReason = 'Empty Relocation (P2)';
          fleet[1].currentTargetStation = STATIONS.PICKUP_2;
          fleet[1].replan();

          addTelemetry('DECONFLICT', 'SCENARIO LOADED: Head-on Aisle Choke Point. AMR-02 should yield to AMR-01.');
        });

        // Scenario 2: 4-Way Crossroad Convergence
        document.getElementById('scen-cross').addEventListener('click', () => {
          clearAllObstacles();
          const cx = 24 * CELL_SIZE + CELL_SIZE / 2;
          const cy = 14 * CELL_SIZE + CELL_SIZE / 2;

          fleet[0].x = cx - 180;
          fleet[0].y = cy;
          fleet[0].heading = 0;
          fleet[0].priority = 4;
          fleet[0].priorityReason = 'Critical Order';
          fleet[0].currentTargetStation = STATIONS.DROPOFF_2;
          fleet[0].replan();

          fleet[1].x = cx + 180;
          fleet[1].y = cy;
          fleet[1].heading = Math.PI;
          fleet[1].priority = 2;
          fleet[1].priorityReason = 'Standard Loaded';
          fleet[1].currentTargetStation = STATIONS.PICKUP_2;
          fleet[1].replan();

          fleet[2].x = cx;
          fleet[2].y = cy + 180;
          fleet[2].heading = -Math.PI / 2;
          fleet[2].priority = 3;
          fleet[2].priorityReason = 'Tote Transfer';
          fleet[2].currentTargetStation = STATIONS.PICKUP_1;
          fleet[2].replan();

          fleet[3].x = cx;
          fleet[3].y = cy - 180;
          fleet[3].heading = Math.PI / 2;
          fleet[3].priority = 1;
          fleet[3].priorityReason = 'Empty Return';
          fleet[3].currentTargetStation = STATIONS.CHARGE_1;
          fleet[3].replan();

          addTelemetry('DECONFLICT', 'SCENARIO LOADED: 4-Way Crossroad Convergence. AMRs negotiating right-of-way symmetrically via P2P.');
        });

        // Scenario 3: Dynamic Obstacle Spill in front of AMR-01
        document.getElementById('scen-spill').addEventListener('click', () => {
          const amr = fleet[0];
          if (amr.path && amr.path.length > amr.pathIndex + 3) {
            const nextWp = amr.path[amr.pathIndex + 2];
            toggleObstacleAtWorldPos(nextWp.x, nextWp.y);
          } else {
            toggleObstacleAtWorldPos(amr.x + 60, amr.y);
          }
        });

        // Scenario 4: Low Battery Priority Override
        document.getElementById('scen-batt').addEventListener('click', () => {
          fleet[1].battery = 14;
          fleet[1].assignNextTask();
          addTelemetry('BATTERY', 'SCENARIO LOADED: AMR-02 battery drained to 14%. Elevated to Priority 5 (Emergency Docking).');
        });

        // Initial Seed Logs
        addTelemetry('P2P', 'Edge-AI Distributed Fleet Bus initialized (Zero-Central-Server architecture).');
        addTelemetry('P2P', '4 Autonomous Mobile Robots active on localized peer-to-peer ad-hoc network.');
        addTelemetry('MISSION', 'Dispatching AMRs to storage racks and picking bays.');

        // --- MANUAL EDITORS & MODAL CONTROLLERS ---
        let currentEditingAmrId = 'AMR-01';

        // 1. AMR Inspector Modal
        const modalAmr = document.getElementById('modal-amr-inspector');
        const amrTabBtns = document.querySelectorAll('.robot-tab-btn');
        const inputAmrName = document.getElementById('edit-amr-name');
        const inputAmrBattery = document.getElementById('edit-amr-battery');
        const lblAmrBattery = document.getElementById('lbl-edit-amr-battery');
        const inputAmrSpeed = document.getElementById('edit-amr-speed');
        const lblAmrSpeed = document.getElementById('lbl-edit-amr-speed');
        const selectAmrState = document.getElementById('edit-amr-state');
        const selectAmrPriority = document.getElementById('edit-amr-priority');
        const inputAmrReason = document.getElementById('edit-amr-priority-reason');
        const chkAmrPayload = document.getElementById('edit-amr-payload');
        const selectAmrStation = document.getElementById('edit-amr-station-select');
        const inputAmrCoordX = document.getElementById('edit-amr-coord-x');
        const inputAmrCoordY = document.getElementById('edit-amr-coord-y');

        function populateAmrEditorForm(amr) {
          if (!amr) return;
          currentEditingAmrId = amr.id;

          amrTabBtns.forEach(btn => {
            btn.classList.toggle('active', btn.dataset.robot === amr.id);
          });

          if (inputAmrName) inputAmrName.value = amr.name;
          if (inputAmrBattery) {
            inputAmrBattery.value = Math.round(amr.battery);
            if (lblAmrBattery) lblAmrBattery.textContent = Math.round(amr.battery) + '%';
          }
          if (inputAmrSpeed) {
            inputAmrSpeed.value = Math.round(amr.maxSpeed);
            if (lblAmrSpeed) lblAmrSpeed.textContent = (amr.maxSpeed / 20).toFixed(1) + ' m/s';
          }
          if (selectAmrState) selectAmrState.value = amr.state;
          if (selectAmrPriority) selectAmrPriority.value = String(amr.priority);
          if (inputAmrReason) inputAmrReason.value = amr.priorityReason || '';
          if (chkAmrPayload) chkAmrPayload.checked = !!amr.carryingPayload;

          if (inputAmrCoordX) inputAmrCoordX.value = Math.round(amr.x);
          if (inputAmrCoordY) inputAmrCoordY.value = Math.round(amr.y);

          // Populate stations dropdown
          if (selectAmrStation) {
            selectAmrStation.innerHTML = '';
            Object.keys(STATIONS).forEach(key => {
              const st = STATIONS[key];
              if (st) {
                const opt = document.createElement('option');
                opt.value = key;
                opt.textContent = `${st.name} (${st.type.toUpperCase()})`;
                if (amr.currentTargetStation?.name === st.name) {
                  opt.selected = true;
                }
                selectAmrStation.appendChild(opt);
              }
            });
          }
        }

        window.openAmrEditor = function(id) {
          const amr = fleet.find(r => r.id === (id || currentEditingAmrId)) || fleet[0];
          if (amr) {
            populateAmrEditorForm(amr);
            selectAMR(amr);
            if (modalAmr) modalAmr.classList.remove('hidden');
          }
        };

        function closeAmrEditor() {
          if (modalAmr) modalAmr.classList.add('hidden');
        }

        document.getElementById('btn-open-amr-editor')?.addEventListener('click', () => {
          window.openAmrEditor(selectedAMR ? selectedAMR.id : 'AMR-01');
        });
        document.getElementById('btn-close-amr-modal')?.addEventListener('click', closeAmrEditor);
        document.getElementById('btn-cancel-amr-edits')?.addEventListener('click', closeAmrEditor);

        amrTabBtns.forEach(btn => {
          btn.addEventListener('click', () => {
            const amr = fleet.find(r => r.id === btn.dataset.robot);
            if (amr) {
              populateAmrEditorForm(amr);
              selectAMR(amr);
            }
          });
        });

        // Quick battery presets
        document.getElementById('btn-batt-15')?.addEventListener('click', () => {
          if (inputAmrBattery) {
            inputAmrBattery.value = 15;
            if (lblAmrBattery) lblAmrBattery.textContent = '15%';
          }
        });
        document.getElementById('btn-batt-50')?.addEventListener('click', () => {
          if (inputAmrBattery) {
            inputAmrBattery.value = 50;
            if (lblAmrBattery) lblAmrBattery.textContent = '50%';
          }
        });
        document.getElementById('btn-batt-80')?.addEventListener('click', () => {
          if (inputAmrBattery) {
            inputAmrBattery.value = 80;
            if (lblAmrBattery) lblAmrBattery.textContent = '80%';
          }
        });
        document.getElementById('btn-batt-100')?.addEventListener('click', () => {
          if (inputAmrBattery) {
            inputAmrBattery.value = 100;
            if (lblAmrBattery) lblAmrBattery.textContent = '100%';
          }
        });

        inputAmrBattery?.addEventListener('input', (e) => {
          if (lblAmrBattery) lblAmrBattery.textContent = e.target.value + '%';
        });
        inputAmrSpeed?.addEventListener('input', (e) => {
          if (lblAmrSpeed) lblAmrSpeed.textContent = (parseFloat(e.target.value) / 20).toFixed(1) + ' m/s';
        });

        // Station Dispatch button
        document.getElementById('btn-edit-dispatch-station')?.addEventListener('click', () => {
          const amr = fleet.find(r => r.id === currentEditingAmrId);
          if (amr && selectAmrStation) {
            const st = STATIONS[selectAmrStation.value];
            if (st) {
              amr.currentTargetStation = st;
              amr.replan();
              addTelemetry('MISSION', `Manual Dispatch: ${amr.id} dispatched to ${st.name}`);
              playCompleteBeep();
            }
          }
        });

        // Coordinate Dispatch button
        document.getElementById('btn-edit-dispatch-coord')?.addEventListener('click', () => {
          const amr = fleet.find(r => r.id === currentEditingAmrId);
          if (amr && inputAmrCoordX && inputAmrCoordY) {
            const x = Math.max(10, Math.min(WORLD_W - 10, parseFloat(inputAmrCoordX.value) || 100));
            const y = Math.max(10, Math.min(WORLD_H - 10, parseFloat(inputAmrCoordY.value) || 100));
            const c = Math.floor(x / CELL_SIZE);
            const r = Math.floor(y / CELL_SIZE);
            amr.setManualDestination(c, r, x, y, 'Manual Waypoint');
            playCompleteBeep();
          }
        });

        // Coordinate Teleport button
        document.getElementById('btn-edit-teleport')?.addEventListener('click', () => {
          const amr = fleet.find(r => r.id === currentEditingAmrId);
          if (amr && inputAmrCoordX && inputAmrCoordY) {
            const x = Math.max(15, Math.min(WORLD_W - 15, parseFloat(inputAmrCoordX.value) || 100));
            const y = Math.max(15, Math.min(WORLD_H - 15, parseFloat(inputAmrCoordY.value) || 100));
            amr.teleport(x, y);
            playTone(750, 'sine', 0.15, 0.05);
          }
        });

        // D-Pad drive buttons
        document.getElementById('dpad-fwd')?.addEventListener('click', () => {
          const amr = fleet.find(r => r.id === currentEditingAmrId);
          if (amr) amr.teleop('fwd');
        });
        document.getElementById('dpad-back')?.addEventListener('click', () => {
          const amr = fleet.find(r => r.id === currentEditingAmrId);
          if (amr) amr.teleop('back');
        });
        document.getElementById('dpad-left')?.addEventListener('click', () => {
          const amr = fleet.find(r => r.id === currentEditingAmrId);
          if (amr) amr.teleop('left');
        });
        document.getElementById('dpad-right')?.addEventListener('click', () => {
          const amr = fleet.find(r => r.id === currentEditingAmrId);
          if (amr) amr.teleop('right');
        });
        document.getElementById('dpad-stop')?.addEventListener('click', () => {
          const amr = fleet.find(r => r.id === currentEditingAmrId);
          if (amr) amr.teleop('stop');
        });

        // Save & Apply AMR edits
        document.getElementById('btn-save-amr-edits')?.addEventListener('click', () => {
          const amr = fleet.find(r => r.id === currentEditingAmrId);
          if (amr) {
            if (inputAmrName) amr.name = inputAmrName.value.trim() || amr.name;
            if (inputAmrBattery) amr.battery = Math.max(5, Math.min(100, parseFloat(inputAmrBattery.value)));
            if (inputAmrSpeed) amr.maxSpeed = Math.max(15, Math.min(120, parseFloat(inputAmrSpeed.value)));
            if (selectAmrState) amr.state = selectAmrState.value;
            if (selectAmrPriority) amr.priority = parseInt(selectAmrPriority.value, 10);
            if (inputAmrReason) amr.priorityReason = inputAmrReason.value.trim() || 'Manual Operator Override';
            if (chkAmrPayload) amr.carryingPayload = chkAmrPayload.checked;

            addTelemetry('P2P', `Manual parameters applied to ${amr.id} (${amr.name}): P${amr.priority}, ${Math.round(amr.battery)}% batt.`);
            updateFleetCardsUI();
            closeAmrEditor();
          }
        });

        // 2. System & Physics Config Modal
        const modalConfig = document.getElementById('modal-system-config');
        const cfgComms = document.getElementById('cfg-comms');
        const lblCfgComms = document.getElementById('lbl-cfg-comms');
        const cfgSafety = document.getElementById('cfg-safety');
        const lblCfgSafety = document.getElementById('lbl-cfg-safety');
        const cfgYield = document.getElementById('cfg-yield');
        const lblCfgYield = document.getElementById('lbl-cfg-yield');
        const cfgHorizon = document.getElementById('cfg-horizon');
        const lblCfgHorizon = document.getElementById('lbl-cfg-horizon');
        const cfgBattery = document.getElementById('cfg-battery');
        const lblCfgBattery = document.getElementById('lbl-cfg-battery');

        function populateSystemConfig() {
          if (cfgComms) { cfgComms.value = COMMS_RADIUS; if (lblCfgComms) lblCfgComms.textContent = COMMS_RADIUS + ' px'; }
          if (cfgSafety) { cfgSafety.value = SAFETY_RADIUS; if (lblCfgSafety) lblCfgSafety.textContent = SAFETY_RADIUS + ' px'; }
          if (cfgYield) { cfgYield.value = YIELD_CLEARANCE; if (lblCfgYield) lblCfgYield.textContent = YIELD_CLEARANCE + ' px'; }
          if (cfgHorizon) { cfgHorizon.value = HORIZON_SECONDS; if (lblCfgHorizon) lblCfgHorizon.textContent = HORIZON_SECONDS + ' s'; }
          if (cfgBattery) { cfgBattery.value = BATTERY_DRAIN_MULTIPLIER; if (lblCfgBattery) lblCfgBattery.textContent = BATTERY_DRAIN_MULTIPLIER.toFixed(2) + 'x'; }
        }

        window.openSystemConfig = function() {
          populateSystemConfig();
          if (modalConfig) modalConfig.classList.remove('hidden');
        };

        function closeSystemConfig() {
          if (modalConfig) modalConfig.classList.add('hidden');
        }

        document.getElementById('btn-open-system-config')?.addEventListener('click', window.openSystemConfig);
        document.getElementById('btn-close-config-modal')?.addEventListener('click', closeSystemConfig);
        document.getElementById('btn-cancel-sys-config')?.addEventListener('click', closeSystemConfig);

        cfgComms?.addEventListener('input', e => { if (lblCfgComms) lblCfgComms.textContent = e.target.value + ' px'; });
        cfgSafety?.addEventListener('input', e => { if (lblCfgSafety) lblCfgSafety.textContent = e.target.value + ' px'; });
        cfgYield?.addEventListener('input', e => { if (lblCfgYield) lblCfgYield.textContent = e.target.value + ' px'; });
        cfgHorizon?.addEventListener('input', e => { if (lblCfgHorizon) lblCfgHorizon.textContent = e.target.value + ' s'; });
        cfgBattery?.addEventListener('input', e => { if (lblCfgBattery) lblCfgBattery.textContent = parseFloat(e.target.value).toFixed(2) + 'x'; });

        document.getElementById('btn-apply-sys-config')?.addEventListener('click', () => {
          if (cfgComms) COMMS_RADIUS = parseFloat(cfgComms.value);
          if (cfgSafety) SAFETY_RADIUS = parseFloat(cfgSafety.value);
          if (cfgYield) YIELD_CLEARANCE = parseFloat(cfgYield.value);
          if (cfgHorizon) HORIZON_SECONDS = parseFloat(cfgHorizon.value);
          if (cfgBattery) BATTERY_DRAIN_MULTIPLIER = parseFloat(cfgBattery.value);

          addTelemetry('P2P', `System Parameters Tuned: Comms=${COMMS_RADIUS}px, Safety=${SAFETY_RADIUS}px, Yield=${YIELD_CLEARANCE}px, Horizon=${HORIZON_SECONDS}s, BattDrain=${BATTERY_DRAIN_MULTIPLIER}x`);
          closeSystemConfig();
        });

        document.getElementById('btn-reset-sys-config')?.addEventListener('click', () => {
          COMMS_RADIUS = 180;
          SAFETY_RADIUS = 26;
          YIELD_CLEARANCE = 44;
          HORIZON_SECONDS = 4.5;
          BATTERY_DRAIN_MULTIPLIER = 1.0;
          populateSystemConfig();
          addTelemetry('P2P', 'System parameters restored to factory defaults.');
        });

        // 3. Layout Raw JSON Modal
        const modalJson = document.getElementById('modal-layout-json');
        const txtLayoutJson = document.getElementById('txt-layout-json');

        function generateLayoutJsonString() {
          const customStationsList = Object.keys(STATIONS)
            .filter(k => STATIONS[k].custom)
            .map(k => STATIONS[k]);

          const data = {
            metadata: {
              title: "Autonomous Mobile Robot Warehouse Layout",
              timestamp: new Date().toISOString(),
              version: "2.4.0"
            },
            grid: {
              cols: GRID_COLS,
              rows: GRID_ROWS,
              cellSize: CELL_SIZE,
              worldWidth: WORLD_W,
              worldHeight: WORLD_H
            },
            dynamicObstacles: Array.from(dynamicObstacles),
            customStations: customStationsList,
            systemParameters: {
              commsRadius: COMMS_RADIUS,
              safetyRadius: SAFETY_RADIUS,
              yieldClearance: YIELD_CLEARANCE,
              horizonSeconds: HORIZON_SECONDS,
              batteryDrainMultiplier: BATTERY_DRAIN_MULTIPLIER
            }
          };
          return JSON.stringify(data, null, 2);
        }

        window.openLayoutJson = function() {
          if (txtLayoutJson) {
            txtLayoutJson.value = generateLayoutJsonString();
          }
          if (modalJson) modalJson.classList.remove('hidden');
        };

        function closeLayoutJson() {
          if (modalJson) modalJson.classList.add('hidden');
        }

        document.getElementById('btn-open-layout-json')?.addEventListener('click', window.openLayoutJson);
        document.getElementById('btn-close-json-modal')?.addEventListener('click', closeLayoutJson);
        document.getElementById('btn-cancel-json')?.addEventListener('click', closeLayoutJson);

        document.getElementById('btn-copy-json')?.addEventListener('click', async function() {
          if (txtLayoutJson) {
            try {
              await navigator.clipboard.writeText(txtLayoutJson.value);
              const orig = this.textContent;
              this.textContent = '✓ Copied!';
              setTimeout(() => { this.textContent = orig; }, 1800);
            } catch (err) {
              txtLayoutJson.select();
              document.execCommand('copy');
            }
          }
        });

        document.getElementById('btn-download-json')?.addEventListener('click', () => {
          if (txtLayoutJson) {
            const blob = new Blob([txtLayoutJson.value], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `warehouse-layout-${Date.now()}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
          }
        });

        document.getElementById('btn-apply-json')?.addEventListener('click', () => {
          if (!txtLayoutJson) return;
          try {
            const data = JSON.parse(txtLayoutJson.value);
            // Apply dynamic obstacles
            if (Array.isArray(data.dynamicObstacles)) {
              clearAllObstacles();
              data.dynamicObstacles.forEach(idx => {
                if (typeof idx === 'number' && idx >= 0 && idx < GRID_COLS * GRID_ROWS) {
                  dynamicObstacles.add(idx);
                  grid[idx] = 2;
                }
              });
            }
            // Apply custom stations
            if (Array.isArray(data.customStations)) {
              data.customStations.forEach((st, i) => {
                const key = `CUSTOM_${i + 1}`;
                STATIONS[key] = {
                  id: key,
                  name: st.name || `Station ${i + 1}`,
                  type: st.type || 'pickup',
                  col: st.col,
                  row: st.row,
                  x: st.x || (st.col * CELL_SIZE + CELL_SIZE / 2),
                  y: st.y || (st.row * CELL_SIZE + CELL_SIZE / 2),
                  custom: true
                };
              });
            }
            // Apply system parameters
            if (data.systemParameters) {
              const sp = data.systemParameters;
              if (typeof sp.commsRadius === 'number') COMMS_RADIUS = sp.commsRadius;
              if (typeof sp.safetyRadius === 'number') SAFETY_RADIUS = sp.safetyRadius;
              if (typeof sp.yieldClearance === 'number') YIELD_CLEARANCE = sp.yieldClearance;
              if (typeof sp.horizonSeconds === 'number') HORIZON_SECONDS = sp.horizonSeconds;
              if (typeof sp.batteryDrainMultiplier === 'number') BATTERY_DRAIN_MULTIPLIER = sp.batteryDrainMultiplier;
            }

            fleet.forEach(amr => amr.replan());
            addTelemetry('P2P', `Loaded and applied layout JSON configuration (${dynamicObstacles.size} obstacles, ${data.customStations?.length || 0} custom stations).`);
            closeLayoutJson();
          } catch (err) {
            alert('Invalid JSON syntax: ' + err.message);
          }
        });

        // 4. Custom Station Modal
        const modalStation = document.getElementById('modal-add-station');
        const inputStationName = document.getElementById('new-station-name');
        const selectStationType = document.getElementById('new-station-type');
        const inputStationCol = document.getElementById('new-station-col');
        const inputStationRow = document.getElementById('new-station-row');
        let nextCustomStationId = 1;

        window.openAddStationModal = function(col, row) {
          pendingStationPos = {
            col: col,
            row: row,
            x: col * CELL_SIZE + CELL_SIZE / 2,
            y: row * CELL_SIZE + CELL_SIZE / 2
          };
          if (inputStationCol) inputStationCol.value = col;
          if (inputStationRow) inputStationRow.value = row;
          if (inputStationName) inputStationName.value = `Dock ${Object.keys(STATIONS).length + 1}`;
          if (modalStation) modalStation.classList.remove('hidden');
        };

        function closeAddStationModal() {
          if (modalStation) modalStation.classList.add('hidden');
        }

        document.getElementById('btn-close-station-modal')?.addEventListener('click', closeAddStationModal);
        document.getElementById('btn-cancel-station')?.addEventListener('click', closeAddStationModal);

        document.getElementById('btn-save-station')?.addEventListener('click', () => {
          const name = inputStationName ? inputStationName.value.trim() : `Custom Station ${nextCustomStationId}`;
          const type = selectStationType ? selectStationType.value : 'pickup';
          const key = `CUSTOM_${nextCustomStationId++}`;

          STATIONS[key] = {
            id: key,
            name: name || `Custom Station`,
            type: type,
            col: pendingStationPos.col,
            row: pendingStationPos.row,
            x: pendingStationPos.x,
            y: pendingStationPos.y,
            custom: true
          };

          addTelemetry('MISSION', `New warehouse station added: "${name}" at cell [${pendingStationPos.col}, ${pendingStationPos.row}].`);
          closeAddStationModal();
          playCompleteBeep();
        });

        // Expose simulation API to AI, Cloud, and Developer Console
        window.__AMR_SIM__ = window.__AMR_SIM__ || {};
        Object.assign(window.__AMR_SIM__, {
          fleet,
          dynamicObstacles,
          STATIONS,
          CELL_SIZE,
          GRID_COLS,
          GRID_ROWS,
          WORLD_W,
          WORLD_H,
          racks,
          addTelemetry,
          toggleObstacleAtWorldPos,
          clearAllObstacles,
          setToolMode,
          getShowAllNav: () => showAllNav,
          setShowAllNav: (val) => {
            showAllNav = !!val;
            if (btnToggleAllNav) {
              btnToggleAllNav.classList.toggle('active', showAllNav);
              btnToggleAllNav.textContent = showAllNav ? '✓ All Nav Shown' : '🧭 Show All Nav';
            }
          },
          openAmrEditor: window.openAmrEditor,
          openSystemConfig: window.openSystemConfig,
          openLayoutJson: window.openLayoutJson,
          openAddStationModal: window.openAddStationModal,
          getObstacleList: () => Array.from(dynamicObstacles),
          setObstacleList: (list) => {
            clearAllObstacles();
            if (Array.isArray(list)) {
              list.forEach(idx => {
                dynamicObstacles.add(idx);
                grid[idx] = 2;
              });
              fleet.forEach(amr => amr.replan());
            }
          },
          getSystemParameters: () => ({
            commsRadius: COMMS_RADIUS,
            safetyRadius: SAFETY_RADIUS,
            yieldClearance: YIELD_CLEARANCE,
            horizonSeconds: HORIZON_SECONDS,
            batteryDrainMultiplier: BATTERY_DRAIN_MULTIPLIER
          }),
          setSystemParameters: (params) => {
            if (!params) return;
            if (typeof params.commsRadius === 'number') COMMS_RADIUS = params.commsRadius;
            if (typeof params.safetyRadius === 'number') SAFETY_RADIUS = params.safetyRadius;
            if (typeof params.yieldClearance === 'number') YIELD_CLEARANCE = params.yieldClearance;
            if (typeof params.horizonSeconds === 'number') HORIZON_SECONDS = params.horizonSeconds;
            if (typeof params.batteryDrainMultiplier === 'number') BATTERY_DRAIN_MULTIPLIER = params.batteryDrainMultiplier;
            populateSystemConfig();
          },
          getTelemetrySnapshot: () => {
            return fleet.map(f => `${f.id} (${f.name}): Pos=(${Math.round(f.x)}, ${Math.round(f.y)}), Battery=${Math.round(f.battery)}%, State=${f.state}, Priority=${f.priority} (${f.priorityReason}), Target=${f.currentTargetStation?.name || 'None'}, CarryingPayload=${f.carryingPayload ? 'Yes' : 'No'}`).join('n');
          },
          setZoom,
          resetZoom,
          getZoomLevel: () => zoomLevel
        });

        // Keyboard shortcuts for quick zoom (+, -, 0)
        window.addEventListener('keydown', (e) => {
          if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
          if (e.key === '+' || e.key === '=') {
            setZoom(zoomLevel + 0.25);
          } else if (e.key === '-' || e.key === '_') {
            setZoom(zoomLevel - 0.25);
          } else if (e.key === '0') {
            resetZoom();
          }
        });
      })();
    </script>
    <script type="module">
      import { initAmrAiAndCloud } from '/src/amr-ai-cloud.ts';
      import '/src/main.tsx';
      window.addEventListener('DOMContentLoaded', () => {
        initAmrAiAndCloud();
      });
      // Also fallback if DOM already loaded
      if (document.readyState === 'interactive' || document.readyState === 'complete') {
        initAmrAiAndCloud();
      }
    </script>
  </body>
</html>
